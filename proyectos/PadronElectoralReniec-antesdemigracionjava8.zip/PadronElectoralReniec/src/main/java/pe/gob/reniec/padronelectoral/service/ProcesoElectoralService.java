/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.service;

import java.io.Serializable;
import java.sql.Connection;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import pe.gob.reniec.padronelectoral.dao.ProcesoElectoralDao;
import pe.gob.reniec.padronelectoral.entity.ProcesoElectoral;

/**
 *
 * @author Hadassa
 */
@Service
public class ProcesoElectoralService implements Serializable {

    @Autowired
    transient ProcesoElectoralDao procesoElectoralDao;

    @Autowired
    private DataSource dataSource;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Connection getConnection() {
        // ....use dataSource to create connection
        return DataSourceUtils.getConnection(dataSource);
    }

    public void setProcesoElectoralDao(ProcesoElectoralDao procesoDao) {
        this.procesoElectoralDao = procesoDao;
    }

    public ProcesoElectoral consultarProcesoActivo() {

        ProcesoElectoral result = null;

        try {
            result = procesoElectoralDao.consultarProcesoElectoral();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;

    }

    public List<ProcesoElectoral> listarProcesosElectorales() {

        List<ProcesoElectoral> result = null;

        try {
            result = procesoElectoralDao.listarProcesosElectorales();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;

    }

    public boolean registrarProcesoElectoral(String co_proceso_electoral, String de_proceso_electoral, String co_usuario, String fe_realizacion) {

        boolean correcto = false;
        ProcesoElectoral proceso = new ProcesoElectoral(co_proceso_electoral, de_proceso_electoral, co_usuario, fe_realizacion);
        try {
            procesoElectoralDao.registrarProcesoElectoral(proceso);
            correcto = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correcto;
    }

    public boolean actualizarProcesoElectoral(String co_proceso_electoral, String de_proceso_electoral, String co_usuario) {

        boolean correcto = false;
        ProcesoElectoral proceso = new ProcesoElectoral(co_proceso_electoral, de_proceso_electoral, co_usuario, "");
        try {
            procesoElectoralDao.actualizarProcesoElectoral(proceso);
            correcto = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correcto;
    }

}
