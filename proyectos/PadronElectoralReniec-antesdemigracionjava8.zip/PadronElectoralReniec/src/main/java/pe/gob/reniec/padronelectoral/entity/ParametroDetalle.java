/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.util.Date;

/**
 *
 * @author eibanez
 */
public class ParametroDetalle {

    private String co_parametro;
    private Long nu_parametro;
    private String de_parametro;
    private Double nu_valor;
    private String de_valor;
    private Date fe_valor;
    private String es_parametro;
    private String us_crea_audi;
    private Date fe_crea_audi;
    private String us_modi_audi;
    private Date fe_modi_audi;
    private String de_etiqueta;

    public ParametroDetalle() {
    }

    public String getCo_parametro() {
        return co_parametro;
    }

    public void setCo_parametro(String co_parametro) {
        this.co_parametro = co_parametro;
    }

    public Long getNu_parametro() {
        return nu_parametro;
    }

    public void setNu_parametro(Long nu_parametro) {
        this.nu_parametro = nu_parametro;
    }

    public String getDe_parametro() {
        return de_parametro;
    }

    public void setDe_parametro(String de_parametro) {
        this.de_parametro = de_parametro;
    }

    public Double getNu_valor() {
        return nu_valor;
    }

    public void setNu_valor(Double nu_valor) {
        this.nu_valor = nu_valor;
    }

    public String getDe_valor() {
        return de_valor;
    }

    public void setDe_valor(String de_valor) {
        this.de_valor = de_valor;
    }

    public Date getFe_valor() {
        return fe_valor;
    }

    public void setFe_valor(Date fe_valor) {
        this.fe_valor = fe_valor;
    }

    public String getEs_parametro() {
        return es_parametro;
    }

    public void setEs_parametro(String es_parametro) {
        this.es_parametro = es_parametro;
    }

    public String getUs_crea_audi() {
        return us_crea_audi;
    }

    public void setUs_crea_audi(String us_crea_audi) {
        this.us_crea_audi = us_crea_audi;
    }

    public Date getFe_crea_audi() {
        return fe_crea_audi;
    }

    public void setFe_crea_audi(Date fe_crea_audi) {
        this.fe_crea_audi = fe_crea_audi;
    }

    public String getUs_modi_audi() {
        return us_modi_audi;
    }

    public void setUs_modi_audi(String us_modi_audi) {
        this.us_modi_audi = us_modi_audi;
    }

    public Date getFe_modi_audi() {
        return fe_modi_audi;
    }

    public void setFe_modi_audi(Date fe_modi_audi) {
        this.fe_modi_audi = fe_modi_audi;
    }

    public String getDe_etiqueta() {
        return de_etiqueta;
    }

    public void setDe_etiqueta(String de_etiqueta) {
        this.de_etiqueta = de_etiqueta;
    }

}
