/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.padronelectoral.entity.ArchivoGenerado;
import pe.gob.reniec.padronelectoral.util.NombreDeTablasUtil;

/**
 *
 * @author Hadassa
 */
@Repository
public interface ArchGenHistoricoDao {

    @Select("INSERT INTO " + NombreDeTablasUtil.Archivo_generado_historico +" (co_continente, co_pais, co_departamento, co_provincia, co_distrito, co_mcp, co_proceso_electoral, us_genera_archivo, fe_genera_archivo, de_archivo_generado, de_justificacion,"
            + " DE_NOM_ARCHIVO_MCP, es_registro, us_crea_audi, fe_crea_audi, in_imagenes) "
            + " VALUES (#{archGenHistorico.co_continente}, #{archGenHistorico.co_pais}, #{archGenHistorico.co_departamento}, #{archGenHistorico.co_provincia}, #{archGenHistorico.co_distrito},"
            + " #{archGenHistorico.co_mcp}, "
            + " #{archGenHistorico.co_proceso_electoral}, #{archGenHistorico.us_genera_archivo}, SYSDATE, #{archGenHistorico.de_archivo_generado}, #{archGenHistorico.de_justificacion}, "
            + " #{archGenHistorico.de_nom_file_mcp}, #{archGenHistorico.es_registro}, #{archGenHistorico.us_crea_audi}, SYSDATE, #{archGenHistorico.in_imagenes} ) ")
    public void registrarArchGenHistorico(@Param("archGenHistorico") ArchivoGenerado archivoGenerado) throws Exception;

}
