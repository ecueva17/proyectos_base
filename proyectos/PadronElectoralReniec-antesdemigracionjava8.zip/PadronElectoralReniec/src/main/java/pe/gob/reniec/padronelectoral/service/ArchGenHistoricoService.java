/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.service;

import java.io.Serializable;
import java.sql.Connection;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import pe.gob.reniec.padronelectoral.dao.ArchGenHistoricoDao;
import pe.gob.reniec.padronelectoral.entity.ArchivoGenerado;

/**
 *
 * @author ESTEBAN
 */
@Service
public class ArchGenHistoricoService implements Serializable {

    final static Logger logger = Logger.getLogger(ArchGenHistoricoService.class);

    @Autowired
    transient ArchGenHistoricoDao archGenHistoricoDao;

    @Autowired
    private DataSource dataSource;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Connection getConnection() {
        return DataSourceUtils.getConnection(dataSource);
    }

    public void setArchGenHistoricoDao(ArchGenHistoricoDao archGenHistoricoDao) {
        this.archGenHistoricoDao = archGenHistoricoDao;
    }

    public void registrarArchGenHistorico(ArchivoGenerado archivoGenerado) throws Exception {
        this.archGenHistoricoDao.registrarArchGenHistorico(archivoGenerado);
    }

}
