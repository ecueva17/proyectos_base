/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author eibanez
 */
@XmlRootElement
public class ResponseBase64 implements Serializable {

    private String de_respuesta;
    private String de_imagen64;
    private String in_referenciado;
    private String point_x;
    private String point_y;

    public String getDe_respuesta() {
        return de_respuesta;
    }

    public void setDe_respuesta(String de_respuesta) {
        this.de_respuesta = de_respuesta;
    }

    public String getDe_imagen64() {
        return de_imagen64;
    }

    public void setDe_imagen64(String de_imagen64) {
        this.de_imagen64 = de_imagen64;
    }

    public String getPoint_x() {
        return point_x;
    }

    public void setPoint_x(String point_x) {
        this.point_x = point_x;
    }

    public String getPoint_y() {
        return point_y;
    }

    public void setPoint_y(String point_y) {
        this.point_y = point_y;
    }

    public String getIn_referenciado() {
        return in_referenciado;
    }

    public void setIn_referenciado(String in_referenciado) {
        this.in_referenciado = in_referenciado;
    }

}
