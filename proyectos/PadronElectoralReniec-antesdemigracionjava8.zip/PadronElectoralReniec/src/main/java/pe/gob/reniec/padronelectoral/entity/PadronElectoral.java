/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

/**
 *
 * @author externo.ecueva
 */
public class PadronElectoral {
    private String nu_dni;
    private String ap_primer;
    private String ap_segundo;
    private String ap_am_nom;
    private String co_departamento;
    private String co_provincia;
    private String co_distrito;
    private String co_mcp;
    private String co_proceso_electoral;

    public PadronElectoral() {
    }

    public PadronElectoral(String co_departamento, String co_provincia, String co_distrito, String co_mcp, String co_proceso_electoral) {
        this.co_departamento = co_departamento;
        this.co_provincia = co_provincia;
        this.co_distrito = co_distrito;
        this.co_mcp = co_mcp;
        this.co_proceso_electoral = co_proceso_electoral;
    }

    public String getNu_dni() {
        return nu_dni;
    }

    public void setNu_dni(String nu_dni) {
        this.nu_dni = nu_dni;
    }

    public String getAp_primer() {
        return ap_primer;
    }

    public void setAp_primer(String ap_primer) {
        this.ap_primer = ap_primer;
    }

    public String getAp_segundo() {
        return ap_segundo;
    }

    public void setAp_segundo(String ap_segundo) {
        this.ap_segundo = ap_segundo;
    }

    public String getAp_am_nom() {
        return ap_am_nom;
    }

    public void setAp_am_nom(String ap_am_nom) {
        this.ap_am_nom = ap_am_nom;
    }

    public String getCo_departamento() {
        return co_departamento;
    }

    public void setCo_departamento(String co_departamento) {
        this.co_departamento = co_departamento;
    }

    public String getCo_provincia() {
        return co_provincia;
    }

    public void setCo_provincia(String co_provincia) {
        this.co_provincia = co_provincia;
    }

    public String getCo_distrito() {
        return co_distrito;
    }

    public void setCo_distrito(String co_distrito) {
        this.co_distrito = co_distrito;
    }

    public String getCo_mcp() {
        return co_mcp;
    }

    public void setCo_mcp(String co_mcp) {
        this.co_mcp = co_mcp;
    }

    public String getCo_proceso_electoral() {
        return co_proceso_electoral;
    }

    public void setCo_proceso_electoral(String co_proceso_electoral) {
        this.co_proceso_electoral = co_proceso_electoral;
    }
}
