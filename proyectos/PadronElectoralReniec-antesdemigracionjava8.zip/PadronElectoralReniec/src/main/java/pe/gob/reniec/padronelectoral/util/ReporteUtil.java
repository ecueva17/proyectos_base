/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.util;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;
import net.sf.jasperreports.engine.fill.JRAbstractLRUVirtualizer;
import net.sf.jasperreports.engine.fill.JRFileVirtualizer;
import net.sf.jasperreports.engine.fill.JRSwapFileVirtualizer;
import net.sf.jasperreports.engine.util.JRSwapFile;
import org.apache.log4j.Logger;

/**
 *
 * @author zmontes
 */
public class ReporteUtil {
    
    public static final Logger logger = Logger.getLogger(ReporteUtil.class);

    private Connection conexionBD;
    private Map parametros;
    private String directorio;
    private String nombreArchivo;

    private JRAbstractLRUVirtualizer virtualizador;
    private JRPdfExporter exportador;

    public ReporteUtil(Connection conexionBD, Map parametros, String directorio, String nombreArchivo) {
        this.conexionBD = conexionBD;
        this.parametros = parametros;
        this.directorio = directorio;
        this.nombreArchivo = nombreArchivo;

        this.exportador = new JRPdfExporter();
    }

    public void exportarReporte() throws JRException {

        this.exportador.setParameter(JRExporterParameter.CHARACTER_ENCODING, "UTF-8");
        this.exportador.setParameter(JRExporterParameter.OUTPUT_FILE, new File(this.directorio + this.nombreArchivo));
        this.exportador.setParameter(JRPdfExporterParameter.IS_COMPRESSED, Boolean.TRUE);
        this.exportador.setParameter(JRPdfExporterParameter.PDF_VERSION, JRPdfExporterParameter.PDF_VERSION_1_3);
        this.exportador.exportReport();

    }

    public int exportarReporteRealizandoSplit(int numPaginasParaSplit, int contadorPDF) throws JRException {

        int paginaInicial = 0;
        int paginaFinal;
        int totalPaginas = ((JasperPrint) exportador.getParameter(JRExporterParameter.JASPER_PRINT)).getPages().size();
        String nombreArchivoConSufijo;

        this.exportador.setParameter(JRExporterParameter.CHARACTER_ENCODING, "UTF-8");

        while (paginaInicial < totalPaginas) {
            paginaFinal = paginaInicial + numPaginasParaSplit - 1;
            this.exportador.setParameter(JRExporterParameter.START_PAGE_INDEX, paginaInicial);
            this.exportador.setParameter(JRExporterParameter.END_PAGE_INDEX, (paginaFinal < totalPaginas) ? paginaFinal : totalPaginas - 1);
            nombreArchivoConSufijo = ArchivoUtil.agregarSufijoANombreDeArchivo(ArchivoUtil.obtenerSufijoNombreReporteConSplit(contadorPDF), this.nombreArchivo);
            this.exportador.setParameter(JRExporterParameter.OUTPUT_FILE, new File(this.directorio + nombreArchivoConSufijo));
            this.exportador.exportReport();
            paginaInicial = paginaFinal + 1;
            contadorPDF++;
        }
        
        return contadorPDF;

    }

    public void configurarJasperPrint(String plantilla) throws JRException {
        JasperPrint jasperPrint = JasperFillManager.fillReport(plantilla, this.parametros, this.conexionBD);
        this.exportador.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
    }

    public void configurarJasperPrint(List<String> plantillas) throws JRException {
        List<JasperPrint> jasperPrints = new ArrayList<JasperPrint>();
        for (String plantilla : plantillas) {
            jasperPrints.add(JasperFillManager.fillReport(plantilla, this.parametros, this.conexionBD));
        }
        this.exportador.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrints);
    }

    public void configurarVirtualizador() throws IOException {
        String directorioTemporal = this.directorio + ConstantesUtil.VIRTUALIZADOR_DIRECTORIO_TEMPORAL;
        ArchivoUtil.crearDirectorio(directorioTemporal);
        crearVirtualizador(ConstantesUtil.VIRTUALIZADOR_MAX_PAGINAS, directorioTemporal, ConstantesUtil.VIRTUALIZADOR_TIPO);
        this.parametros.put(JRParameter.REPORT_VIRTUALIZER, this.virtualizador);
    }

    public void crearVirtualizador(int numMaxDePaginas, String tmpDirectorio, String tipoVirtualizador) {
        if (tipoVirtualizador.equalsIgnoreCase("file")) {
            this.virtualizador = new JRFileVirtualizer(numMaxDePaginas, tmpDirectorio);
            this.virtualizador.setReadOnly(true);
        } else {
            int blockSize = 2048;
            int minGrowCount = 1024;
            JRSwapFile swapFile = new JRSwapFile(tmpDirectorio, blockSize, minGrowCount);
            this.virtualizador = new JRSwapFileVirtualizer(numMaxDePaginas, swapFile);
        }
    }

    public Connection getConexionBD() {
        return conexionBD;
    }

    public void setConexionBD(Connection conexionBD) {
        this.conexionBD = conexionBD;
    }

    public Map getParametros() {
        return parametros;
    }

    public void setParametros(Map parametros) {
        this.parametros = parametros;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public String getDirectorio() {
        return directorio;
    }

    public void setDirectorio(String directorio) {
        this.directorio = directorio;
    }

}
