/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class Restriccion implements Serializable {

    private String co_restri;
    private String de_restri;
    private String ti_restri;

    public Restriccion() {

    }

    public String getCo_restri() {
        return co_restri;
    }

    public void setCo_restri(String co_restri) {
        this.co_restri = co_restri;
    }

    public String getDe_restri() {
        return de_restri;
    }

    public void setDe_restri(String de_restri) {
        this.de_restri = de_restri;
    }

    public String getTi_restri() {
        return ti_restri;
    }

    public void setTi_restri(String ti_restri) {
        this.ti_restri = ti_restri;
    }

}
