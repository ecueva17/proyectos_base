/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class UsuarioPorRol extends Auditoria implements Serializable {

    private String nu_dni;
    private String co_rol;

    public UsuarioPorRol(String nu_dni, String co_rol, String co_usuario) {
        this.nu_dni = nu_dni;
        this.co_rol = co_rol;
        this.es_registro = "1";
        this.us_crea_audi = co_usuario;
        this.us_modi_audi = co_usuario;
    }

    public UsuarioPorRol(String co_rol) {
        this.co_rol = co_rol;
    }

    public String getNu_dni() {
        return nu_dni;
    }

    public void setNu_dni(String nu_dni) {
        this.nu_dni = nu_dni;
    }

    public String getCo_rol() {
        return co_rol;
    }

    public void setCo_rol(String co_rol) {
        this.co_rol = co_rol;
    }

}
