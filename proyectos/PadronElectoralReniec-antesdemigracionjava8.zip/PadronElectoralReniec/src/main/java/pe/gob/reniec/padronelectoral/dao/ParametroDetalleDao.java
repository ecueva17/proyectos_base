/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.padronelectoral.entity.ParametroDetalle;
import pe.gob.reniec.padronelectoral.util.NombreDeTablasUtil;

/**
 *
 * @author eibanez
 */
@Repository
public interface ParametroDetalleDao {

    @Select("SELECT t.de_parametro, t.nu_valor, t.de_valor, t.fe_valor FROM " + NombreDeTablasUtil.ParametroDetalle
            + " t WHERE t.co_parametro = #{co_parametro} and t.de_parametro = #{de_parametro} and t.es_parametro = '1' ")
    public ParametroDetalle obtenerParametroPorDescripcion(@Param("co_parametro") String co_parametro, @Param("de_parametro") String de_parametro) throws Exception;
}
