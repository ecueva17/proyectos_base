/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.dao;

import java.util.List;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.padronelectoral.entity.Modulo;
import pe.gob.reniec.padronelectoral.util.NombreDeTablasUtil;

/**
 *
 * @author Hadassa
 */
@Repository
public interface ModuloDao {
    
    final String SELECT_MENU_ROL=   "select * from (\n" +
                                        "       select m.co_modulo, \n" +
                                        "              m.de_modulo, \n" +
                                        "              m.co_padre, \n" +
                                        "              m.de_url, \n" +
                                        "              m.nu_orden \n" +
                                        "       from " + NombreDeTablasUtil.Modulo + " m " +
                                        "       right join " + NombreDeTablasUtil.ModuloPorRol + " mr on m.co_modulo=mr.co_modulo\n" +
                                        "       where mr.co_rol=#{co_rol} and mr.es_registro=1 and m.es_registro=1\n" +
                                        ")\n" +
                                        "START WITH co_padre=0 \n" +
                                        "CONNECT BY co_padre = PRIOR co_modulo \n" +
                                        "order siblings by nu_orden asc";
    
    @Select(SELECT_MENU_ROL)    
    public List<Modulo> obtenerListaPorRol(String co_rol);

}
