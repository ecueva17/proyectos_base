/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.padronelectoral.entity.ProcesoElectoral;
import pe.gob.reniec.padronelectoral.util.NombreDeTablasUtil;

/**
 *
 * @author Hadassa
 */
@Repository
public interface ProcesoElectoralDao {

    @Select("SELECT t.co_proceso_electoral, t.de_proceso_electoral, t.fe_realizacion  FROM " + NombreDeTablasUtil.Proceso_electoral 
            + " t WHERE es_registro = '1' ")
    public ProcesoElectoral consultarProcesoElectoral() throws Exception;

    @Select("SELECT co_proceso_electoral, de_proceso_electoral, fe_realizacion  FROM " + NombreDeTablasUtil.Proceso_electoral 
            + " WHERE es_registro = '1' ")
    public List<ProcesoElectoral> listarProcesosElectorales() throws Exception;

    @Select("INSERT INTO " + NombreDeTablasUtil.Proceso_electoral +" (co_proceso_electoral, de_proceso_electoral, fe_realizacion, "
            + "es_registro, us_crea_audi, fe_crea_audi, us_modi_audi, fe_modi_audi) "
            + "VALUES (#{procesoElectoral.co_proceso_electoral}, #{procesoElectoral.de_proceso_electoral}, #{procesoElectoral.fe_realizacion},"
            + "#{procesoElectoral.es_registro}, #{procesoElectoral.us_crea_audi}, SYSDATE, #{procesoElectoral.us_modi_audi}, SYSDATE ) ")
    public void registrarProcesoElectoral(@Param("procesoElectoral") ProcesoElectoral procesoElectoral) throws Exception;
    
    @Select("UPDATE " + NombreDeTablasUtil.Proceso_electoral +" "
            + "SET de_proceso_electoral = #{procesoElectoral.de_proceso_electoral}, "
            + "fe_realizacion = #{procesoElectoral.us_modi_audi},"
            + "us_modi_audi = #{procesoElectoral.us_modi_audi},"
            + "fe_modi_audi = SYSDATE "
            + "WHERE co_proceso_electoral = #{procesoElectoral.co_proceso_electoral}")
    public void actualizarProcesoElectoral(@Param("procesoElectoral") ProcesoElectoral procesoElectoral) throws Exception;

}
