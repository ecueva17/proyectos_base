/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.gob.reniec.padronelectoral.dao.ModuloDao;
import pe.gob.reniec.padronelectoral.entity.Modulo;

/**
 *
 * @author Hadassa
 */
@Service
public class ModuloService {

    @Autowired
    ModuloDao moduloDao;

    public void setModuloDao(ModuloDao moduloDao) {
        this.moduloDao = moduloDao;
    }
    
    public List<Modulo> obtenerListaPorRol(String co_rol){
        return moduloDao.obtenerListaPorRol(co_rol);
    }

}
