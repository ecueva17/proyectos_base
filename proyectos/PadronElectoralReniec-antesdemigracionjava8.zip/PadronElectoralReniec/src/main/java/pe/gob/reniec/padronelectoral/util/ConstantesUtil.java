/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pe.gob.reniec.padronelectoral.util;

/**
 *
 * @author zmontes
 */
public final class ConstantesUtil {
    
    public static final int FOTO_CIUDADANO_JSON_WIDTH = 66;
    public static final int FOTO_CIUDADANO_JSON_HEIGHT = 76;    
    public static final int FOTO_CIUDADANO_PDF_WIDTH = 29;
    public static final int FOTO_CIUDADANO_PDF_HEIGHT = 60;
    
    public static final int VIRTUALIZADOR_MAX_PAGINAS = 1000;
    public static final String VIRTUALIZADOR_DIRECTORIO_TEMPORAL = "tmp";
    public static final String VIRTUALIZADOR_TIPO = "swap";
    
    public static final int REPORTE_NUM_PAG_PARA_SPLIT = 14;
    public static final int REPORTE_TAMANIO_PDF_PARA_SPLIT = 1848;

    public static double POSICICON_SaN = -Math.PI / 2.0;
    public static double POSICICON_NaS = Math.PI / 2.0;
    public static double POSICICON_SOaNE = -Math.PI / 4.0;
    public static double POSICICON_NOaSE = Math.PI / 4.0;
    
    public static final String EXTENSION_PDF = ".pdf";
    public static final String EXTENSION_ZIP = ".zip";
    public static final String EXTENSION_EXCEL = ".xls";
    
    public enum INDICADOR {
        NO("0"),
        SI("1");
        private final String estado;

        private INDICADOR(String estado) {
            this.estado = estado;
        }
        public String getValor() {
            return estado;
        }
    }
    
}
