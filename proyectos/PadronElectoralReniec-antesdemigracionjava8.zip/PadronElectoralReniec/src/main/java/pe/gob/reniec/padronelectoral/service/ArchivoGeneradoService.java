/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.service;

import java.io.Serializable;
import java.sql.Connection;
import java.util.List;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import pe.gob.reniec.padronelectoral.dao.ArchivoGeneradoDao;
import pe.gob.reniec.padronelectoral.entity.ArchivoGenerado;
import pe.gob.reniec.padronelectoral.entity.UbigeoPorProceso;

/**
 *
 * @author ESTEBAN
 */
@Service
public class ArchivoGeneradoService implements Serializable{

    final static Logger logger = Logger.getLogger(ArchivoGeneradoService.class);

    @Autowired
    transient ArchivoGeneradoDao archivogeneradoDao;

    @Autowired
    private DataSource dataSource;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Connection getConnection() {
        return DataSourceUtils.getConnection(dataSource);
    }

    public void setArchivogeneradoDao(ArchivoGeneradoDao archivogeneradoDao) {
        this.archivogeneradoDao = archivogeneradoDao;
    }

    public ArchivoGenerado consultarArchivoGenerado(ArchivoGenerado archivoGenerado) {
        try {
            return archivogeneradoDao.consultarArchivoGenerado(archivoGenerado);
        } catch (Exception e) {
            logger.error("Sistema: ", e);
        }
        return null;
    }

    public ArchivoGenerado consultarArchivoGeneradoIndicandoImagenes(ArchivoGenerado archivoGenerado) {
        try {
            return archivogeneradoDao.consultarArchivoGeneradoIndicandoImagenes(archivoGenerado);
        } catch (Exception e) {
            logger.error("Sistema: ", e);
        }
        return null;
    }

    public void registrarArchivoGenerado(ArchivoGenerado archivoGenerado) throws Exception {
            archivogeneradoDao.registrarArchivoGenerado(archivoGenerado);
    }

    public List<UbigeoPorProceso> listarDepartamentosGenerados(String co_proceso_electoral, String co_continente, String co_pais) throws Exception {
        return archivogeneradoDao.listarDepartamentosGenerados(co_proceso_electoral, co_continente, co_pais);
    }

    public List<UbigeoPorProceso> listarProvinciasGeneradas(String co_proceso_electoral, String co_continente, String co_pais, String co_departamento) throws Exception {
        return archivogeneradoDao.listarProvinciasGeneradas(co_proceso_electoral, co_continente, co_pais, co_departamento);
    }

    public List<UbigeoPorProceso> listarDistritosGenerados(String co_proceso_electoral, String co_continente, String co_pais, String co_departamento, String co_provincia) throws Exception {
        return archivogeneradoDao.listarDistritosGenerados(co_proceso_electoral, co_continente, co_pais, co_departamento, co_provincia);
    }
    
    public List<UbigeoPorProceso> listarMCPGenerados(String co_proceso_electoral, String co_continente, 
            String co_pais, String co_departamento, String co_provincia, String co_dis) throws Exception {
        return archivogeneradoDao.listarMCPGenerados(co_proceso_electoral, co_continente, co_pais, co_departamento, co_provincia, co_dis);
    }

    public void actualizarCaFormatosGenerados(ArchivoGenerado archivoGenerado) throws Exception {
        archivogeneradoDao.actualizarCaFormatosGenerados(archivoGenerado);
    }
    
    public String getPasswordArchivo(String nomFile){
        return archivogeneradoDao.obtenerPasswordArchivo(nomFile);
    }
    
    public String obtenerClaveArchivoGenerado(String co_proceso_electoral, String co_continente, 
            String co_pais, String co_departamento, String co_provincia, String co_dis, String co_mcp) throws Exception {
        return archivogeneradoDao.obtenerClaveArchivoGenerado(co_proceso_electoral, co_continente, co_pais, co_departamento, co_provincia, co_dis, co_mcp);
    }
}
