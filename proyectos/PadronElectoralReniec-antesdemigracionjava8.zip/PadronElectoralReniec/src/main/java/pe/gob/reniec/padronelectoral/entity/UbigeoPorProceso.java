/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class UbigeoPorProceso extends Auditoria implements Serializable {

    private String co_continente;
    private String co_pais;
    private String co_departamento;
    private String co_provincia;
    private String co_distrito;
    private String co_proceso_electoral;
    private String no_departamento;
    private String no_provincia;
    private String no_distrito;
    private Integer nu_prioridad;
    private String co_mcp;
    private String no_mcp;
    
    //Transient
    private String ca_formatos_generados;
    private String in_imagenes;

    public UbigeoPorProceso(String co_continente, String co_pais, String co_departamento, String co_provincia, String co_distrito, String co_proceso_electoral, String co_usuario) {
        this.co_continente = co_continente;
        this.co_pais = co_pais;
        this.co_departamento = co_departamento;
        this.co_provincia = co_provincia;
        this.co_distrito = co_distrito;
        this.co_proceso_electoral = co_proceso_electoral;
        this.es_registro = "1";
        this.us_crea_audi = co_usuario;
        this.us_modi_audi = co_usuario;
    }

    public UbigeoPorProceso() {
    }

    public String getCo_continente() {
        return co_continente;
    }

    public void setCo_continente(String co_continente) {
        this.co_continente = co_continente;
    }

    public String getCo_pais() {
        return co_pais;
    }

    public void setCo_pais(String co_pais) {
        this.co_pais = co_pais;
    }

    public String getCo_departamento() {
        return co_departamento;
    }

    public void setCo_departamento(String co_departamento) {
        this.co_departamento = co_departamento;
    }

    public String getCo_provincia() {
        return co_provincia;
    }

    public void setCo_provincia(String co_provincia) {
        this.co_provincia = co_provincia;
    }

    public String getCo_distrito() {
        return co_distrito;
    }

    public void setCo_distrito(String co_distrito) {
        this.co_distrito = co_distrito;
    }

    public String getCo_proceso_electoral() {
        return co_proceso_electoral;
    }

    public void setCo_proceso_electoral(String co_proceso_electoral) {
        this.co_proceso_electoral = co_proceso_electoral;
    }

    public String getNo_departamento() {
        return no_departamento;
    }

    public void setNo_departamento(String no_departamento) {
        this.no_departamento = no_departamento;
    }

    public String getNo_provincia() {
        return no_provincia;
    }

    public void setNo_provincia(String no_provincia) {
        this.no_provincia = no_provincia;
    }

    public String getNo_distrito() {
        return no_distrito;
    }

    public void setNo_distrito(String no_distrito) {
        this.no_distrito = no_distrito;
    }

    public Integer getNu_prioridad() {
        return nu_prioridad;
    }

    public void setNu_prioridad(Integer nu_prioridad) {
        this.nu_prioridad = nu_prioridad;
    }

    public String getCa_formatos_generados() {
        return ca_formatos_generados;
    }

    public void setCa_formatos_generados(String ca_formatos_generados) {
        this.ca_formatos_generados = ca_formatos_generados;
    }

    public String getIn_imagenes() {
        return in_imagenes;
    }

    public void setIn_imagenes(String in_imagenes) {
        this.in_imagenes = in_imagenes;
    }

    public String getCo_mcp() {
        return co_mcp;
    }

    public void setCo_mcp(String co_mcp) {
        this.co_mcp = co_mcp;
    }

    public String getNo_mcp() {
        return no_mcp;
    }

    public void setNo_mcp(String no_mcp) {
        this.no_mcp = no_mcp;
    }
    
}
