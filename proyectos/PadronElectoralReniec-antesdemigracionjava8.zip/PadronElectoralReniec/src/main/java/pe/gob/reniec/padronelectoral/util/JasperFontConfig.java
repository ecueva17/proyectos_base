
package pe.gob.reniec.padronelectoral.util;

/**
 *
 * @author externo.rgutierreze
 */
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.io.InputStream;
import java.util.Collection;

import net.sf.jasperreports.engine.fonts.SimpleFontExtensionHelper;
import net.sf.jasperreports.engine.util.JRStyledTextParser;
import net.sf.jasperreports.engine.util.JRFontUtil;

public class JasperFontConfig implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            // inicializaciones necesarias
            JRStyledTextParser.getInstance();

            ClassLoader cl = Thread.currentThread().getContextClassLoader();

            // intenta cargar por InputStream desde el classpath dentro del JAR
            String xmlPath = "fonts/fonts1392244921682.xml"; // <-- ajusta si es distinto
            InputStream is = cl.getResourceAsStream(xmlPath);

            if (is != null) {
                // carga el fonts XML (firma disponible en 5.x)
                SimpleFontExtensionHelper.getInstance().loadFontFamilies(is);
                System.out.println("Cargado fonts XML desde classpath: " + xmlPath);
            } else {
                // fallback por ruta (si tu JAR registra rutas)
                SimpleFontExtensionHelper.getInstance().loadFontFamilies(xmlPath);
                System.out.println("Intentado cargar fonts por ruta: " + xmlPath);
            }

            // debug: listar familias registradas
            Collection<String> fams = JRFontUtil.getFontFamilyNames();
            System.out.println("Fuentes registradas tras carga:");
            for (String f : fams) System.out.println(" - " + f);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) { }
}
