/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.padronelectoral.entity.PadronElectoral;
import pe.gob.reniec.padronelectoral.entity.PadronElectoralExcelDTO;
import pe.gob.reniec.padronelectoral.util.NombreDeTablasUtil;

/**
 *
 * @author externo.ecueva
 */
@Repository
public interface PadronElectoralDao {
    
    @Select("SELECT t.nu_dni as dni," +
                " t.prenom_inscrito as nombres, " +
                " t.ap_primer as primer_apellido, " +
                " t.ap_segundo as segundo_apellido " +
                " FROM " + NombreDeTablasUtil.Ciudadano + " t" +
                " where t.CO_DEPARTAMEN_DOMICILIO_RENIEC =#{padron.co_departamento} " +
                " and t.CO_PROVINCIA_DOMICILIO_RENIEC=#{padron.co_provincia} " +
                " and t.CO_DISTRITO_DOMICILIO_RENIEC=#{padron.co_distrito} " +
                " and t.CO_MUNI_CENTRO_POBLADO=#{padron.co_mcp} " +
                " and t.co_proceso_electoral=#{padron.co_proceso_electoral} " +
                " and t.co_restri = ' ' " +
                " ORDER BY t.ap_primer, t.ap_segundo, t.prenom_inscrito ASC")
    List<PadronElectoralExcelDTO> ConsultaPadronElectoral(@Param("padron") PadronElectoral padronElectoral);
}
