/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.padronelectoral.entity.Rol;
import pe.gob.reniec.padronelectoral.util.NombreDeTablasUtil;

/**
 *
 * @author Hadassa
 */
@Repository
public interface RolDao {

    @Select("SELECT r.co_rol, r.de_rol, r.no_rol  FROM " + NombreDeTablasUtil.Rol + " r "
            + "       inner join " + NombreDeTablasUtil.UsuarioPorRol + " ur on r.co_rol=ur.co_rol\n"
            + " WHERE ur.nu_dni=#{nu_dni} AND ur.es_registro = '1' AND r.es_registro = '1' ")
    public Rol obtenerRol(@Param("nu_dni") String nu_dni) throws Exception;

}
