/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.service;

import java.io.Serializable;
import java.sql.Connection;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import pe.gob.reniec.padronelectoral.dao.UbigeoPorProcesoDao;
import pe.gob.reniec.padronelectoral.entity.UbigeoPorProceso;

/**
 *
 * @author Hadassa
 */
@Service
public class UbigeoPorProcesoService implements Serializable {

    @Autowired
    transient UbigeoPorProcesoDao ubigeoXprocesoDao;
    @Autowired
    private DataSource dataSource;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Connection getConnection() {
        return DataSourceUtils.getConnection(dataSource);
    }

    public void setUbigeoPorProcesoDao(UbigeoPorProcesoDao moduloDao) {
        this.ubigeoXprocesoDao = moduloDao;
    }

    public List<UbigeoPorProceso> listarUbigeosPorProcesoYUsuario(String co_proceso, String usuario) throws Exception {
        return ubigeoXprocesoDao.listarUbigeosPorProcesoYUsuario(co_proceso, usuario);
    }

    public void registrarUbigeoPorProceso(UbigeoPorProceso ubigeoXproceso) throws Exception {
        ubigeoXprocesoDao.registrarUbigeoPorProceso(ubigeoXproceso);
    }

    public void eliminarUbigeos(String co_proceso_electoral, String usuario) throws Exception {
        ubigeoXprocesoDao.eliminarUbigeos(co_proceso_electoral, usuario);
    }
    
    public void actualizarEstado(UbigeoPorProceso ubigeoXproceso) throws Exception{
        ubigeoXprocesoDao.actualizarEstado(ubigeoXproceso);
    }
    
    public Long obtenerCantidadRegistrosConEstadoGenerandoEnUbigeo(UbigeoPorProceso ubigeoXproceso) throws Exception{
        return ubigeoXprocesoDao.obtenerCantidadRegistrosConEstadoGenerandoEnUbigeo(ubigeoXproceso);
    }
    
    public Long obtenerCantidadRegistrosCoincidentesConUbigeo(UbigeoPorProceso ubigeoXproceso) throws Exception{
        return ubigeoXprocesoDao.obtenerCantidadRegistrosCoincidentesConUbigeo(ubigeoXproceso);
    }
}
