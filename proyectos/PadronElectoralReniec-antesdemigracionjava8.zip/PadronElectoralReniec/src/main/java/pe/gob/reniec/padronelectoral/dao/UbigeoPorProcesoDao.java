/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.dao;

import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.padronelectoral.entity.UbigeoPorProceso;
import pe.gob.reniec.padronelectoral.util.NombreDeTablasUtil;

/**
 *
 * @author Hadassa
 */
@Repository
public interface UbigeoPorProcesoDao {

    @Select("SELECT t.co_proceso_electoral, t.co_continente, t.co_pais, t.co_departamento, t.co_provincia, t.co_distrito, t.CO_MCP, t.nu_prioridad, u.no_departamento, "
            + " u.no_provincia, u.no_distrito, u.NO_MUNI_CENTRO_POBLADO as no_mcp, t.us_crea_audi "
            + " FROM " + NombreDeTablasUtil.UbigeoPorProceso + " t "
            + " LEFT JOIN " + NombreDeTablasUtil.Ubigeo + " u "
            + " ON u.CO_CONTINENTE_RENIEC = t.co_continente AND u.CO_PAIS_RENIEC = t.co_pais AND u.CO_DEPARTAMENTO_RENIEC = t.co_departamento AND u.CO_PROVINCIA_RENIEC = t.co_provincia "
            + " AND u.CO_DISTRITO_RENIEC = t.co_distrito AND u.CO_MUNI_CENTRO_POBLADO = t.CO_MCP "
            + " WHERE t.co_proceso_electoral = #{co_proceso_electoral} AND t.es_registro = '1' AND t.us_crea_audi = #{us_crea_audi} "
            + " GROUP BY t.co_proceso_electoral, t.co_continente, t.co_pais, t.co_departamento, t.co_provincia, t.co_distrito, t.CO_MCP, t.nu_prioridad, u.no_departamento, "
            + " u.no_provincia, u.no_distrito, u.NO_MUNI_CENTRO_POBLADO, t.us_crea_audi "
            + " ORDER BY t.nu_prioridad")
    public List<UbigeoPorProceso> listarUbigeosPorProcesoYUsuario(@Param("co_proceso_electoral") String co_proceso_electoral, @Param("us_crea_audi") String usuario) throws Exception;

    @Insert("INSERT INTO " + NombreDeTablasUtil.UbigeoPorProceso + " (co_proceso_electoral, co_continente, co_pais, co_departamento, co_provincia, co_distrito, CO_MCP, "
            + " nu_prioridad, es_registro, us_crea_audi, fe_crea_audi) "
            + " VALUES (#{ubigeoXproceso.co_proceso_electoral}, #{ubigeoXproceso.co_continente},#{ubigeoXproceso.co_pais},#{ubigeoXproceso.co_departamento},#{ubigeoXproceso.co_provincia}, "
            + " #{ubigeoXproceso.co_distrito}, #{ubigeoXproceso.co_mcp}, #{ubigeoXproceso.nu_prioridad}, "
            + " #{ubigeoXproceso.es_registro}, #{ubigeoXproceso.us_crea_audi}, SYSDATE) ")
    public void registrarUbigeoPorProceso(@Param("ubigeoXproceso") UbigeoPorProceso ubigeoXproceso) throws Exception;
    
    @Delete("DELETE FROM "+ NombreDeTablasUtil.UbigeoPorProceso + " u WHERE u.co_proceso_electoral = #{co_proceso_electoral} AND u.us_crea_audi = #{us_crea_audi}")
    public void eliminarUbigeos(@Param("co_proceso_electoral") String co_proceso_electoral, @Param("us_crea_audi") String usuario) throws Exception;

    @Update("UPDATE " + NombreDeTablasUtil.UbigeoPorProceso +" SET es_registro = #{ubigeoXproceso.es_registro}, US_MODI_AUDI = #{ubigeoXproceso.us_crea_audi}, FE_MODI_AUDI = SYSDATE "
            + " WHERE co_proceso_electoral=#{ubigeoXproceso.co_proceso_electoral} AND co_continente = '92' AND co_pais = '33' AND co_departamento=#{ubigeoXproceso.co_departamento} "
            + " AND co_provincia=#{ubigeoXproceso.co_provincia} AND co_distrito=#{ubigeoXproceso.co_distrito} "
            + " AND CO_MCP = #{ubigeoXproceso.co_mcp} AND us_crea_audi = #{ubigeoXproceso.us_crea_audi} ")
    public void actualizarEstado(@Param("ubigeoXproceso") UbigeoPorProceso ubigeoXproceso) throws Exception;

    @Select("SELECT COUNT(1)"
            + " FROM " + NombreDeTablasUtil.UbigeoPorProceso
            + " WHERE co_proceso_electoral=#{ubigeoXproceso.co_proceso_electoral} AND co_continente = '92' AND co_pais = '33'"
            + " AND co_departamento=#{ubigeoXproceso.co_departamento} AND co_provincia=#{ubigeoXproceso.co_provincia} AND co_distrito=#{ubigeoXproceso.co_distrito} "
            + " AND CO_MCP = #{ubigeoXproceso.co_mcp} AND es_registro = '2' ")
    public Long obtenerCantidadRegistrosConEstadoGenerandoEnUbigeo(@Param("ubigeoXproceso") UbigeoPorProceso ubigeoXproceso) throws Exception;
    
    @Select("SELECT COUNT(1)"
            + " FROM " + NombreDeTablasUtil.Ubigeo + " u "
            + " WHERE u.CO_CONTINENTE_RENIEC = '92' AND u.CO_PAIS_RENIEC = '33' AND u.CO_DEPARTAMENTO_RENIEC = #{ubigeoXproceso.co_departamento} AND u.CO_PROVINCIA_RENIEC = #{ubigeoXproceso.co_provincia} "
            + " AND u.CO_DISTRITO_RENIEC = #{ubigeoXproceso.co_distrito} and u.CO_MUNI_CENTRO_POBLADO=#{ubigeoXproceso.co_mcp} ")
    public Long obtenerCantidadRegistrosCoincidentesConUbigeo(@Param("ubigeoXproceso") UbigeoPorProceso ubigeoXproceso) throws Exception;

}
