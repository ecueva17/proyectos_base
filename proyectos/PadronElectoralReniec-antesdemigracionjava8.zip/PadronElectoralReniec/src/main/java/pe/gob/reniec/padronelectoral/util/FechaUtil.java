/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pe.gob.reniec.padronelectoral.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author zmontes
 */
public class FechaUtil {

    public static String obtenerFechaActual() {
        SimpleDateFormat formateador = new SimpleDateFormat("dd/MM/yyyy");
        return formateador.format(new Date());
    }

    public static String formatearFecha(Date fecha, String formato) {
        if (fecha == null) {
            return "";
        }
        SimpleDateFormat formateador = new SimpleDateFormat(formato, new Locale("es", "ES"));
        return formateador.format(fecha);
    }
    
}
