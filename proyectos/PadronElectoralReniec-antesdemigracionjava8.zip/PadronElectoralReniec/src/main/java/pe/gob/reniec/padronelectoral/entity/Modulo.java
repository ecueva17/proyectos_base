/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class Modulo extends Auditoria implements Serializable {

    private String co_modulo;
    private String de_modulo;
    private String co_padre;
    private String de_url;

    public Modulo(String co_modulo, String de_modulo, String co_usuario) {
        this.co_modulo = co_modulo;
        this.de_modulo = de_modulo;
        this.es_registro = "1";
        this.us_crea_audi = co_usuario;
        this.us_modi_audi = co_usuario;
    }

    public Modulo(String co_modulo, String de_modulo, String co_usuario, String val) {
        this.co_modulo = co_modulo;
        this.de_modulo = de_modulo;
        this.us_modi_audi = co_usuario;
    }

    public Modulo() {
    }

    public String getCo_padre() {
        return co_padre;
    }

    public void setCo_padre(String co_padre) {
        this.co_padre = co_padre;
    }

    public String getDe_url() {
        return de_url;
    }

    public void setDe_url(String de_url) {
        this.de_url = de_url;
    }

    public Modulo(String co_modulo) {
        this.co_modulo = co_modulo;
    }

    public String getCo_modulo() {
        return co_modulo;
    }

    public void setCo_modulo(String co_modulo) {
        this.co_modulo = co_modulo;
    }

    public String getDe_modulo() {
        return de_modulo;
    }

    public void setDe_modulo(String de_modulo) {
        this.de_modulo = de_modulo;
    }

}
