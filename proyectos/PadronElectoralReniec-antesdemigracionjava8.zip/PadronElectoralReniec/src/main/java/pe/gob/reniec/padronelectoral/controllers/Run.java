/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.controllers;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Security;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
import pe.gob.reniec.padronelectoral.util.ArchivoUtil;
import pe.gob.reniec.padronelectoral.util.FTPUtil;

/**
 *
 * @author externo.ecueva
 */
public class Run {
    /*public static void main(String[] args) {
        // 1. Crear el libro de trabajo (Workbook)
        Workbook libro = new HSSFWorkbook();
        
        // 2. Crear una hoja (Sheet)
        Sheet hoja = libro.createSheet("Mi Hoja 1");
        
        // 3. Crear una fila (Row) en la posición 0 (primera fila)
        Row fila = hoja.createRow(0);
        
        // 4. Crear una celda (Cell) en la posición 0 (columna A)
        Cell celda = fila.createCell(0);
        
        // 5. Poner valor a la celda
        celda.setCellValue("Hola Mundo desde Java 6");

        // 6. Escribir el archivo a disco
        FileOutputStream out = null;
        try {
            out = new FileOutputStream("ExcelJava6.xls");
            libro.write(out);
            System.out.println("Archivo Excel generado con éxito.");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }*/
    
    /*public static void main(String[] args) {
        // 1. Crear la estructura de la tabla
        List<List<String>> tablaPrueba = new ArrayList<List<String>>();

        // 2. Agregar encabezados (opcional, pero recomendado)
        tablaPrueba.add(Arrays.asList("Nombres", "Apellidos","DNI"));

        // 3. Agregar filas de datos (recordando que el índice 3 será numérico según tu lógica)
        tablaPrueba.add(Arrays.asList("Elvis Iván", "Cueva Odar", "02498388"));
        tablaPrueba.add(Arrays.asList("002", null, "2"));
        tablaPrueba.add(Arrays.asList("003", "Carlos Ruiz", "10"));
        tablaPrueba.add(Arrays.asList("004", "Ana Garcia", "1"));

        // 4. Definir ruta y nombre (Asegúrate de que la carpeta exista)
        String directorio = "C://"; // Usa "/" o File.separator
        String nombreArchivoExcel = "ReportePrueba.xls";

        try {
            // Llamada a tu método
            ArchivoUtil.crearArchivoXLS(tablaPrueba, directorio + nombreArchivoExcel, "password");
            System.out.println("Prueba finalizada: Archivo creado en " + directorio + nombreArchivoExcel);
        } catch (Exception e) {
            System.err.println("Error en la prueba: " + e.getMessage());
            e.printStackTrace();
        }
        
        String nombreArchivoZip = "ReportePrueba.zip";
        
        try {
            // Llamada a tu método
            ArchivoUtil.crearArchivoZip(directorio + nombreArchivoZip, "password", directorio + nombreArchivoExcel);
            System.out.println("Prueba finalizada: Archivo creado en " + directorio + nombreArchivoZip);
        } catch (Exception e) {
            System.err.println("Error en la prueba: " + e.getMessage());
            e.printStackTrace();
        }
    }*/
    
   
    //public static void main(String[] args) {
//        System.out.println("--- DIAGNÓSTICO DE CLASSPATH ---");
//        ClassLoader cl = ClassLoader.getSystemClassLoader();
//        java.net.URL[] urls = ((java.net.URLClassLoader)cl).getURLs();
//        for(java.net.URL url: urls){
//            System.out.println(url.getFile());
//        }
        
        //String rutaArchivo = "C://LPI140618_0001.pdf";
        //String rutaArchivoDestino = "C://LPI140618_0001_seg.pdf";
        //String password = "password";
        
        //ArchivoUtil.seguridadPDF(rutaArchivo, "password", rutaArchivoDestino);
        // Añadimos el proveedor de seguridad de Bouncy Castle dinámicamente
//        if (Security.getProvider("BC") == null) {
//            Security.addProvider(new BouncyCastleProvider());
//        }
        // Esto obliga a usar la versión 1.46 físicamente cargada
        //java.security.Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
        //try {
        //     ArchivoUtil.crearArchivoPDFconSeguridad(rutaArchivo, password, rutaArchivoDestino);
        //} catch(Exception e){
        //    System.err.println("Error en la prueba: " + e.getMessage());
        //    e.printStackTrace(); 
        //}
        
        /*String rutaDirectorio = "D:\\prueba-archivos-seguridad";
        List<String> misPdfs = ArchivoUtil.obtenerListaRutasPDF(rutaDirectorio);
        
        for (int i = 0; i < misPdfs.size(); i++) {
            ArchivoUtil.crearArchivoPDFconSeguridad(misPdfs.get(i), "password");
        }*/
    //}
    /*public static void main(String[] args) {
        try {
            FTPUtil ftpUtil = new FTPUtil("servicesftps.reniec.gob.pe",
                    21,
                    "padmuniappW",
                    "99N7dJA6P1");
            ftpUtil.conectar();
            ftpUtil.subirArchivo("", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
    
    public static void main(String[] args) {
        Md5PasswordEncoder encoder = new Md5PasswordEncoder();
        
        // El segundo parámetro es el 'salt'. Si no usas uno, pon null.
        String hashed = encoder.encodePassword("12345", null);
        
        System.out.println("MD5 Hash: " + hashed);
        // El resultado para "12345" será: 827ccb0eea8a706c4c34a16891f84e7b
    }
    
    /*public static void main(String[] args) {
        String rutaArchivo = "C://mipruebapdf//mi-word.pdf";
        String password = "A+8hlEO!hCJ7jZR=GyiY!8#lJV+WoLku";
        ArchivoUtil.crearArchivoPDFconSeguridad(rutaArchivo, password);
    }*/
}
