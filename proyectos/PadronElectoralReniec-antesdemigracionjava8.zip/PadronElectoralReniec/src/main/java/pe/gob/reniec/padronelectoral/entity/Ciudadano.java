/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;
import pe.gob.reniec.padronelectoral.util.ConstantesUtil;
import pe.gob.reniec.padronelectoral.util.ImagenUtil;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class Ciudadano implements Serializable {

    @JsonProperty("nuDni")
    private String nu_dni;
    @JsonProperty("gpVotacion")
    private String gp_votacion;
    @JsonProperty("apPrimer") 
    private String ap_primer;
    @JsonProperty("apSegundo")
    private String ap_segundo;
    @JsonProperty("deDireccion")
    private String de_direccion;
    @JsonProperty("in_caducidad")
    private String in_caducidad;
    @JsonIgnore  
    private String ap_casada;
    @JsonIgnore
    private String ap_am_nom;
    @JsonProperty("prenomInscrito") 
    private String prenom_inscrito;
    @JsonProperty("imFoto")
    private byte[] im_foto;
    @JsonIgnore  
    private String co_restri;
    @JsonIgnore  
    private String co_continente_domicilio;
    @JsonIgnore  
    private String co_pais_domicilio;
    @JsonIgnore  
    private String co_departamento_domicilio;
    @JsonIgnore  
    private String co_provincia_domicilio;
    @JsonIgnore  
    private String co_distrito_domicilio;
    @JsonIgnore  
    private String co_centro_poblado_domicilio;
    @JsonIgnore  
    private String co_restr = "A";

    public Ciudadano() {
    }

    public Ciudadano(String nu_dni) {
        this.nu_dni = nu_dni;
    }

    public Ciudadano(String co_departamento_domicilio, String co_provincia_domicilio, String co_distrito_domicilio) {
        this.co_departamento_domicilio = co_departamento_domicilio;
        this.co_provincia_domicilio = co_provincia_domicilio;
        this.co_distrito_domicilio = co_distrito_domicilio;
    }

    public String getNu_dni() {
        return nu_dni;
    }

    public void setNu_dni(String nu_dni) {
        this.nu_dni = nu_dni;
    }

    public String getGp_votacion() {
        return gp_votacion;
    }

    public void setGp_votacion(String gp_votacion) {
        this.gp_votacion = gp_votacion;
    }

    public String getAp_primer() {
        return ap_primer;
    }

    public void setAp_primer(String ap_primer) {
        this.ap_primer = ap_primer;
    }

    public String getAp_segundo() {
        return ap_segundo;
    }

    public void setAp_segundo(String ap_segundo) {
        this.ap_segundo = ap_segundo;
    }

    public String getAp_casada() {
        return ap_casada;
    }

    public void setAp_casada(String ap_casada) {
        this.ap_casada = ap_casada;
    }

    public String getPrenom_inscrito() {
        return prenom_inscrito;
    }

    public void setPrenom_inscrito(String prenom_inscrito) {
        this.prenom_inscrito = prenom_inscrito;
    }

    public byte[] getIm_foto() {
        if(this.im_foto != null && this.im_foto.length > 0){
            byte[] fotoTrabajada = ImagenUtil.escalar(this.im_foto, ConstantesUtil.FOTO_CIUDADANO_JSON_HEIGHT);
            return fotoTrabajada;
        }
        return this.im_foto;
    }

    public void setIm_foto(byte[] im_foto) {
        this.im_foto = im_foto;
    }

    public String getCo_restri() {
        return co_restri;
    }

    public void setCo_restri(String co_restri) {
        this.co_restri = co_restri;
    }

    public String getCo_continente_domicilio() {
        return co_continente_domicilio;
    }

    public void setCo_continente_domicilio(String co_continente_domicilio) {
        this.co_continente_domicilio = co_continente_domicilio;
    }

    public String getCo_pais_domicilio() {
        return co_pais_domicilio;
    }

    public void setCo_pais_domicilio(String co_pais_domicilio) {
        this.co_pais_domicilio = co_pais_domicilio;
    }

    public String getCo_departamento_domicilio() {
        return co_departamento_domicilio;
    }

    public void setCo_departamento_domicilio(String co_departamento_domicilio) {
        this.co_departamento_domicilio = co_departamento_domicilio;
    }

    public String getCo_provincia_domicilio() {
        return co_provincia_domicilio;
    }

    public void setCo_provincia_domicilio(String co_provincia_domicilio) {
        this.co_provincia_domicilio = co_provincia_domicilio;
    }

    public String getCo_distrito_domicilio() {
        return co_distrito_domicilio;
    }

    public void setCo_distrito_domicilio(String co_distrito_domicilio) {
        this.co_distrito_domicilio = co_distrito_domicilio;
    }

    public String getCo_centro_poblado_domicilio() {
        return co_centro_poblado_domicilio;
    }

    public void setCo_centro_poblado_domicilio(String co_centro_poblado_domicilio) {
        this.co_centro_poblado_domicilio = co_centro_poblado_domicilio;
    }

    public String getAp_am_nom() {
        String a = ap_primer == null ? "" : ap_primer.replace(" ", "_");
        String b = ap_segundo == null ? "" : ap_segundo.replace(" ", "_");
        String c = prenom_inscrito == null ? "" : prenom_inscrito.replace(" ", "_");
        return a + "_" + b + "_" + c;
    }

    public String getCo_restr() {
        return co_restr;
    }

    public void setCo_restr(String co_restr) {
        this.co_restr = co_restr;
    }

    public String getDe_direccion() {
        return de_direccion;
    }

    public void setDe_direccion(String de_direccion) {
        this.de_direccion = de_direccion;
    }

    public String getIn_caducidad() {
        return in_caducidad;
    }

    public void setIn_caducidad(String in_caducidad) {
        this.in_caducidad = in_caducidad;
    }

    @Override
    public String toString() {
        return "Ciudadano{" + "nu_dni=" + nu_dni + ", gp_votacion=" + gp_votacion + ", ap_primer=" + ap_primer + ", ap_segundo=" + ap_segundo + ", de_direccion=" + de_direccion + ", in_caducidad=" + in_caducidad + ", ap_casada=" + ap_casada + ", ap_am_nom=" + ap_am_nom + ", prenom_inscrito=" + prenom_inscrito + ", im_foto=" + im_foto + ", co_restri=" + co_restri + ", co_continente_domicilio=" + co_continente_domicilio + ", co_pais_domicilio=" + co_pais_domicilio + ", co_departamento_domicilio=" + co_departamento_domicilio + ", co_provincia_domicilio=" + co_provincia_domicilio + ", co_distrito_domicilio=" + co_distrito_domicilio + ", co_centro_poblado_domicilio=" + co_centro_poblado_domicilio + ", co_restr=" + co_restr + '}';
    }

}
