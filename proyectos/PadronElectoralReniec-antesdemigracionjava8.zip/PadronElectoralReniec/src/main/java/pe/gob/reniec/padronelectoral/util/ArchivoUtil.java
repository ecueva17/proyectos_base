/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.zip.ZipOutputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author eibanez
 */
public final class ArchivoUtil {

    final static Logger logger = Logger.getLogger(ArchivoUtil.class);

    public static void crearDirectorio(String directorio) throws IOException {
        File file = new File(directorio);
        FileUtils.forceMkdir(file);
    }

    public static void eliminarArchivo(String directorio, String nombre) throws IOException {
        File file = new File(directorio + nombre);
        file.delete();
    }

    public static void eliminarArchivosDeDirectorio(String directorio) throws IOException {
        File file = new File(directorio);
        File[] lista = file.listFiles();
        if (lista != null) {
            for (File item : file.listFiles()) {
                if (item.isFile()) {
                    item.delete();
                }
            }  
        }
    }

    public static String crearArchivoJsonDeUnObjeto(Object objeto, String directorio, String nombre) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        mapper.writeValue(new File(directorio + nombre), objeto);
        return directorio + nombre;
    }

    public static void crearArchivoTxtDeUnObjeto(Object objeto, String directorio, String nombre) throws FileNotFoundException, IOException {
        FileOutputStream fos = new FileOutputStream(directorio + nombre);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(objeto);
        oos.close();
    }

    public static void crearArchivoExcel(List<List<String>> tabla, String directorio, String nombre) throws IOException {

        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet();
        int f = 0;
        int c;

        for (List<String> fila : tabla) {
            HSSFRow row = sheet.createRow(f);
            f++;
            c = 0;
            for (String dato : fila) {
                HSSFCell cell = row.createCell(c);
                if(c == 3){
                    cell.setCellValue(Util.convertirStringAEntero(dato));
                }else{
                    cell.setCellValue(dato);
                }
                
                c++;
            }
        }

        FileOutputStream fos = new FileOutputStream(directorio + nombre);

        wb.write(fos);
        fos.flush();
        fos.close();
    }

    public static void escribirExcelEnResponse(String directorio, String nombreArchivoSinExtension, HttpServletResponse response) throws FileNotFoundException, IOException {
        File f = new File(directorio + "/" + nombreArchivoSinExtension + ".xls");
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-Disposition", "attachment;filename=\"" + nombreArchivoSinExtension + ".xls\"");
        InputStream in = new FileInputStream(f);
        ServletOutputStream sos = response.getOutputStream();

        int bit = 256;
        while ((bit) >= 0) {
            bit = in.read();
            sos.write(bit);
        }

        sos.flush();
        sos.close();
        in.close();
    }

    public static void copiarStream(InputStream is, OutputStream os) throws IOException {
        byte bytes[] = new byte[8192];
        int bytesRead = is.read(bytes);
        while (bytesRead != -1) {
            os.write(bytes, 0, bytesRead);
            os.flush();
            bytesRead = is.read(bytes);
        }
    }

    public static void cerrarStreams(InputStream is, OutputStream os) throws IOException {
        if (is != null) {
            is.close();
        }
        if (os != null) {
            os.close();
        }
    }

    public static void cerrarStreams(InputStream is, ZipOutputStream zos) throws IOException {
        if (is != null) {
            is.close();
        }
        if (zos != null) {
            zos.closeEntry();
        }
    }

    public static void cerrarOutputStream(OutputStream os) throws IOException {
        if (os != null) {
            os.close();
        }
    }

    public static String agregarSufijoANombreDeArchivo(String sufijo, String nombreArchivo) {
        String aux[] = nombreArchivo.split("\\.");
        return aux[0] + sufijo + "." + aux[1];
    }

    public static String obtenerSufijoNombreReporteConSplit(Integer i) {
        return "_" + ("0000" + i).substring(i.toString().length());
    }

    /*public static void splitPDF(String directorio, String nombreArchivo, int tamanioParaSplit) throws IOException, DocumentException {
        PdfReader original = new PdfReader(directorio + nombreArchivo);
        Document document = null;
        PdfCopy particion = null;

        int paginas = original.getNumberOfPages();
        int pagina = 0;
        int tamanioBytes;
        float tamanioKB = 0;
        String nombreArchivoConSufijo;

        for (int i = 1; i <= paginas; i++) {
            if (tamanioKB == 0) {
                pagina++;
                document = new Document();
                nombreArchivoConSufijo = agregarSufijoANombreDeArchivo(obtenerSufijoNombreReporteConSplit(pagina), nombreArchivo);
                particion = new PdfCopy(document, new FileOutputStream(directorio + nombreArchivoConSufijo));
                document.open();
            }

            particion.addPage(particion.getImportedPage(original, i));
            tamanioBytes = particion.getCurrentDocumentSize();
            tamanioKB = (float) tamanioBytes / 1024;
            if (tamanioKB > tamanioParaSplit || i == paginas) {
                document.close();
                tamanioKB = 0;
            }
        }
    }*/
    
    public static void splitPDF(String directorio, String nombreArchivo, int tamanioParaSplitKB) throws IOException, DocumentException {
        PdfReader original = null;
        Document document = null;
        PdfCopy particion = null;
        FileOutputStream fos = null;

        try {
            original = new PdfReader(directorio + nombreArchivo);
            int totalPaginas = original.getNumberOfPages();
            int contadorParte = 0;
            float tamanioActualKB = 0;

            for (int i = 1; i <= totalPaginas; i++) {
                if (tamanioActualKB == 0) {
                    contadorParte++;
                    document = new Document();
                    String nombreConSufijo = agregarSufijoANombreDeArchivo(
                        obtenerSufijoNombreReporteConSplit(contadorParte), 
                        nombreArchivo
                    );

                    fos = new FileOutputStream(directorio + nombreConSufijo);
                    particion = new PdfCopy(document, fos);
                    document.open();
                }

                particion.addPage(particion.getImportedPage(original, i));
                particion.flush(); 

                long tamanioBytes = particion.getCurrentDocumentSize();
                tamanioActualKB = (float) tamanioBytes / 1024;

                if (tamanioActualKB >= tamanioParaSplitKB || i == totalPaginas) {
                    // CIERRE CONTROLADO (Lógica de negocio)
                    if (document != null) { document.close(); document = null; }
                    if (particion != null) { particion.close(); particion = null; }
                    if (fos != null) { fos.close(); fos = null; }
                    tamanioActualKB = 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new IOException("Error procesando split: " + e.getMessage());
        } finally {
            // CIERRE DE SEGURIDAD (Cláusula finally)
            // Importante: cerrar en orden inverso a la apertura
            if (document != null && document.isOpen()) {
                document.close();
            }
            if (fos != null) {
                try { fos.close(); } catch (IOException e) { /* ignorar */ }
            }
            if (original != null) {
                original.close();
            }
        }
    }

    
    public static File convertirMultipartFileAArchivo(MultipartFile multipart) throws IllegalStateException, IOException {
        File file = new File(multipart.getOriginalFilename());
        multipart.transferTo(file);
        return file;
    }
    
    public static boolean validarCeldaTexto(Cell cell, Integer longitudPermitida){
        if(cell.getCellType() == Cell.CELL_TYPE_STRING && cell.getStringCellValue().length() == longitudPermitida)
            return true;
        return false;
    }
    
    public static boolean validarCeldaNumero(Cell cell, Integer maximoPermitido){
        if(cell.getCellType() == Cell.CELL_TYPE_NUMERIC && cell.getNumericCellValue() <= maximoPermitido)
            return true;
        return false;
    }
    
    /*public static void _crearArchivoXLS(List<List<String>> tabla, String rutaArchivo, String password) throws IOException {
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet();

        for (int i = 0; i < tabla.size(); i++) {
            HSSFRow row = sheet.createRow(i);
            List<String> filaDatos = tabla.get(i);
            for (int j = 0; j < filaDatos.size(); j++) {
                row.createCell(j).setCellValue(filaDatos.get(j));
            }
        }
        
        // 2. BLOQUEAR HOJA (Evita editar celdas)
        // El usuario podrá ver los datos pero no cambiarlos
        sheet.protectSheet(password);

        // 3. BLOQUEAR ESTRUCTURA DEL LIBRO (Evita borrar/añadir hojas)
        // En HSSF se usa para proteger pestañas y ventanas
        wb.writeProtectWorkbook(password, "Autor");
        
        FileOutputStream fos = new FileOutputStream(rutaArchivo);
        wb.write(fos);
        fos.close();
    }*/
    
    public static <T> boolean crearArchivoXLS(List<T> lista, String rutaArchivo, String password) throws IOException {
        boolean result = false;
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Datos");

        if (lista == null || lista.isEmpty()) {
            return result;
        }

        FileOutputStream fos = null;
        try {
            // 1. Obtener la clase y sus campos mediante Reflexión
            Class clase = lista.get(0).getClass();
            Field[] campos = clase.getDeclaredFields();
            
            // Crear Fila de Encabezado (Nombres de los atributos)
            HSSFRow headerRow = sheet.createRow(0);
            for (int i = 0; i < campos.length; i++) {
                headerRow.createCell(i).setCellValue(campos[i].getName().toUpperCase());
            }

            // 2. Llenar los datos de la lista
            for (int i = 0; i < lista.size(); i++) {
                HSSFRow row = sheet.createRow(i + 1);
                T objeto = lista.get(i);
                sheet.autoSizeColumn(i +1);

                for (int j = 0; j < campos.length; j++) {
                    campos[j].setAccessible(true); // Permite leer campos privados
                    Object valor = campos[j].get(objeto);
                    
                    HSSFCell cell = row.createCell(j);
                    if (valor != null) {
                        cell.setCellValue(valor.toString());
                    } else {
                        cell.setCellValue("");
                    }
                }
            }

            // 3. Bloqueos de seguridad (XLS Estándar)
            sheet.protectSheet(password);
            wb.writeProtectWorkbook(password, "Autor");

            // 4. Escritura de archivo (Cierre manual para Java 6)
            fos = new FileOutputStream(rutaArchivo);
            wb.write(fos);
            result = true;
        } catch (Exception e) {
            throw new IOException("Error procesando lista : " + e.getMessage());
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    // Manejo silencioso del cierre
                }
            }
        }
        return result;
    }
    
    /*public static void crearArchivoXLSX(List<List<String>> tabla, String rutaArchivo, String password) throws IOException {
        // 1. Crear el libro y la hoja en memoria (XSSF)
        XSSFWorkbook wb = new XSSFWorkbook();
        XSSFSheet sheet = wb.createSheet("Datos");

        for (int i = 0; i < tabla.size(); i++) {
            XSSFRow row = sheet.createRow(i);
            List<String> filaDatos = tabla.get(i);
            for (int j = 0; j < filaDatos.size(); j++) {
                row.createCell(j).setCellValue(filaDatos.get(j));
            }
        }

        // 2. Proteger la hoja (Evita edición de celdas al abrir)
        sheet.protectSheet(password);

        // 3. Encriptar el libro (Contraseña de apertura)
        try {
            // En POI 3.9 usamos Standard, ya que Agile es para versiones superiores
            POIFSFileSystem fs = new POIFSFileSystem();
            EncryptionInfo info = new EncryptionInfo(fs, EncryptionMode.standard);
            Encryptor enc = info.getEncryptor();
            enc.confirmPassword(password);

            // Paso intermedio: Escribir el Workbook a un buffer
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            wb.write(baos);
            byte[] b = baos.toByteArray();

            // Envolver el contenido en el flujo encriptado
            OutputStream os = enc.getDataStream(fs);
            os.write(b);
            os.close();

            // Guardar físicamente el contenedor POIFS
            FileOutputStream fos = new FileOutputStream(rutaArchivo);
            fs.writeFilesystem(fos);
            fos.close();

            // Limpieza
            wb.close(); 
        } catch (Exception e) {
            // Si hay error de "clase no encontrada", verifica que tengas poi-ooxml
            throw new IOException("Error encriptando XLSX en Java 6: " + e.getMessage());
        }
    }*/
    
    public static boolean crearArchivoZip(String rutaArchivoZip, String password, String rutaDeArchivoAincluirEnZip){
        boolean result = false;
        // 2. Crear el archivo ZIP y protegerlo
        try {
            ZipFile zipFile = new ZipFile(rutaArchivoZip);
            
            // Configurar parámetros del ZIP
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            
            // Activar cifrado
            parameters.setEncryptFiles(true);
            parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD); // AES es más fuerte pero Standard es más compatible
            parameters.setPassword(password);

            // Agregar el archivo Excel al ZIP
            zipFile.addFile(new File(rutaDeArchivoAincluirEnZip), parameters);
            
            // 3. Opcional: Borrar el archivo Excel original para que solo quede el ZIP
            //new File(rutaArchivoIncluirZip).delete();
            
            System.out.println("ZIP creado con éxito en: " + rutaArchivoZip);
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return result;
    }
    
    /*public static void crearArchivoPDFconSeguridad(String rutaArchivo, String password, String rutaDestino) throws IOException {
        // Añadimos el proveedor de seguridad de Bouncy Castle dinámicamente
        //if (Security.getProvider("BC") == null) {
        //    Security.addProvider(new BouncyCastleProvider());
        //}
        try {
            PdfReader reader = new PdfReader(rutaArchivo);
            // 1. ELIMINACIÓN DE METADATOS
            // Creamos un mapa vacío para sobrescribir autor, historial, etc.
            HashMap<String, String> info = new HashMap<String, String>();
            info.put("Author", "");
            info.put("Title", "Reporte Seguro");
            info.put("Subject", "");
            info.put("Keywords", "");
            info.put("Creator", "");
            info.put("Producer", "");

            FileOutputStream fos = new FileOutputStream(rutaDestino);
            //PdfStamper stamper = new PdfStamper(reader, fos);
            
            //permite modificar el archivo y no crear nuevamente
            PdfStamper stamper = new PdfStamper(reader, fos, '\0', true); 


            // Aplicar los metadatos limpios
            stamper.setMoreInfo(info);

            // 2. CONTRASEÑA Y RESTRICCIONES (Bloqueo de Copia y Edición)
            stamper.setEncryption(
                password.getBytes(),           // Password de usuario (para abrir)
                password.getBytes(),           // Password de dueño (para permisos)
                PdfWriter.ALLOW_PRINTING,      // Solo permitimos imprimir
                PdfWriter.ENCRYPTION_AES_256   // Encriptación fuerte
            );

            // Al NO incluir PdfWriter.ALLOW_COPY ni PdfWriter.ALLOW_MODIFY_CONTENTS, 
            // el pegado y la edición quedan bloqueados.

            stamper.close();
            reader.close();
            System.out.println("PDF Protegido y Metadatos limpios.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
    
    public static void crearArchivoPDFconSeguridad(String rutaArchivo, String password) {
        String rutaTemporal = rutaArchivo + ".tmp"; // Archivo auxiliar
        File original = new File(rutaArchivo);
        File temporal = new File(rutaTemporal);

        PdfReader reader = null;
        PdfStamper stamper = null;
        FileOutputStream fos = null;
        
        boolean procesadoExitoso = false;

        try {
            // Para archivos grandes, usamos RandomAccessFile para no cargar todo en RAM
            reader = new PdfReader(rutaArchivo);
            fos = new FileOutputStream(temporal);

            stamper = new PdfStamper(reader, fos, '\0', false);
            //PdfStamper stamper = new PdfStamper(reader, fos);

            // 1. LIMPIEZA DE METADATOS
            HashMap<String, String> info = new HashMap<String, String>();
            //info.put("Author", "");
            //info.put("Title", "title");
            //info.put("Producer", "");
            info.put("Author", "");
            info.put("Title", "Reporte Seguro");
            info.put("Subject", "");
            info.put("Keywords", "");
            info.put("Creator", "");
            info.put("Producer", "");
            stamper.setMoreInfo(info);
            
            // 2. SEGURIDAD
            /*stamper.setEncryption(
                password.getBytes(),
                password.getBytes(),
                PdfWriter.ALLOW_PRINTING,
                PdfWriter.ENCRYPTION_AES_256
            );*/
            stamper.setEncryption(
                password.getBytes(),
                null,
                PdfWriter.ALLOW_PRINTING,
                PdfWriter.ENCRYPTION_AES_128
            );
            
            procesadoExitoso = true;

        } catch (Exception e) {
            System.err.println("Error procesando: " + rutaArchivo);
            e.printStackTrace();
        } finally {
            //if (temporal.exists()) temporal.delete(); // Limpiar basura si falla
            if(stamper!=null){
                try {
                    stamper.close();
                } catch (Exception e) {
                }
            }
            if(reader!=null){
                try {
                    reader.close();
                } catch (Exception e) {
                }
            }
            if(fos!=null){
                try {
                    fos.close();
                } catch (Exception e) {
                }
            }
        }
        
        if(procesadoExitoso){
            // 3. REEMPLAZO DEL ARCHIVO (Sobreescritura física)
            if (original.delete()) {
                if (!temporal.renameTo(original)) {
                    //throw new IOException("No se pudo renombrar el archivo temporal en Linux.");
                    System.err.println("No se pudo renombrar el archivo temporal en Linux.");
                }
            } else {
                //throw new IOException("No se pudo eliminar el original para sobreescribir.");
                System.err.println("No se pudo eliminar el original para sobreescribir.");
            }
        }else if (temporal.exists()) {
            temporal.delete();
        }
    }

    
    public static List<String> obtenerListaRutasPDF(String rutaDirectorio) {
        List<String> listaRutas = new ArrayList<String>();
        File carpeta = new File(rutaDirectorio);

        if (carpeta.exists() && carpeta.isDirectory()) {
            // Filtramos por nombre para no crear objetos File innecesarios
            String[] nombresArchivos = carpeta.list(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.toLowerCase().endsWith(".pdf");
                }
            });

            if (nombresArchivos != null) {
                for (int i = 0; i < nombresArchivos.length; i++) {
                    // Construimos la ruta completa
                    String rutaCompleta = carpeta.getAbsolutePath() + File.separator + nombresArchivos[i];
                    listaRutas.add(rutaCompleta);
                }
            }
        } else {
            System.err.println("La ruta no es un directorio válido.");
        }
        return listaRutas;
    }
    
}
