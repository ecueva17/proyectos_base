/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pe.gob.reniec.padronelectoral.util;

import org.apache.log4j.Logger;

/**
 *
 * @author zmontes
 */
public final class Util {
    
    final static Logger logger = Logger.getLogger(Util.class);
    
    public static Integer convertirStringAEntero(String cadena) {
        try {
            return Integer.parseInt(cadena);
        } catch (NumberFormatException e) {
            logger.error("Sistema: ", e);
        }
        return null;
    }
    
    public static String agregarFormatoAdelante(String formato, String cadena){
        return (formato + cadena).substring(cadena.length());
    }
    
}
