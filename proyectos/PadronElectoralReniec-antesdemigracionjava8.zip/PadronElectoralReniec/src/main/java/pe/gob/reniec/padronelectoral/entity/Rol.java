/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class Rol extends Auditoria implements Serializable {

    private String co_rol;
    private String de_rol;
    private String no_rol;

    public Rol(String co_rol, String de_rol, String no_rol, String co_usuario) {
        this.co_rol = co_rol;
        this.es_registro = "1";
        this.us_crea_audi = co_usuario;
        this.us_modi_audi = co_usuario;
    }

    public Rol(String co_rol, String de_rol, String no_rol, String co_usuario, String val) {
        this.co_rol = co_rol;
        this.de_rol = de_rol;
        this.no_rol = no_rol;
        this.us_crea_audi = co_usuario;
    }

    public Rol() {
    }

    public Rol(String co_rol) {
        this.co_rol = co_rol;
    }

    public String getDe_rol() {
        return de_rol;
    }

    public void setDe_rol(String de_rol) {
        this.de_rol = de_rol;
    }

    public String getNo_rol() {
        return no_rol;
    }

    public void setNo_rol(String no_rol) {
        this.no_rol = no_rol;
    }

    public String getCo_rol() {
        return co_rol;
    }

    public void setCo_rol(String co_rol) {
        this.co_rol = co_rol;
    }

}
