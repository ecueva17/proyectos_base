/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.service;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.util.List;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import pe.gob.reniec.padronelectoral.dao.PadronElectoralDao;
import pe.gob.reniec.padronelectoral.entity.PadronElectoral;
import pe.gob.reniec.padronelectoral.entity.PadronElectoralExcelDTO;
import pe.gob.reniec.padronelectoral.util.ArchivoUtil;
import pe.gob.reniec.padronelectoral.util.ConstantesUtil;

/**
 *
 * @author externo.ecueva
 */
@Service
public class PadronElectoralService implements Serializable{
    
    final static Logger logger = Logger.getLogger(PadronElectoralService.class);
    
    @Autowired
    transient PadronElectoralDao padronElectoralDao;
    
    @Autowired
    private DataSource dataSource;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Connection getConnection() {
        return DataSourceUtils.getConnection(dataSource);
    }

    public void setPadronElectoralDao(PadronElectoralDao padronElectoralDao) {
        this.padronElectoralDao = padronElectoralDao;
    }
    
    private List<PadronElectoralExcelDTO> ConsultaPadronElectoral(PadronElectoral padronElectoral) {
        return this.padronElectoralDao.ConsultaPadronElectoral(padronElectoral);
    }
    
    public boolean generarExcelPadronElectoral(PadronElectoral padronElectoral, String rutaDestino, String nombreArchivo, String pass) throws IOException{
        boolean result;
        String nombreArchivoExcel = nombreArchivo + ConstantesUtil.EXTENSION_EXCEL;
        String nombreArchivoZip = nombreArchivo + ConstantesUtil.EXTENSION_ZIP;
        List<PadronElectoralExcelDTO> list = this.ConsultaPadronElectoral(padronElectoral);
        result = ArchivoUtil.crearArchivoXLS(list, rutaDestino + nombreArchivoExcel, pass);
        if(result)
            result = ArchivoUtil.crearArchivoZip(rutaDestino + nombreArchivoZip, pass, rutaDestino + nombreArchivoExcel);
        if(result)
            ArchivoUtil.eliminarArchivo(rutaDestino, nombreArchivoExcel);
        return result;
    }
}
