/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;

/**
 *
 * @author eibanez
 */
public class RespuestaJSON implements Serializable {

    private String ti_respuesta;
    private String de_mensaje;
    private String de_contenido;

    public RespuestaJSON(String ti_respuesta, String de_mensaje) {
        this.ti_respuesta = ti_respuesta;
        this.de_mensaje = de_mensaje;
    }

    public RespuestaJSON(String ti_respuesta, String de_mensaje, String de_contenido) {
        this.ti_respuesta = ti_respuesta;
        this.de_mensaje = de_mensaje;
        this.de_contenido = de_contenido;
    }

    public String getTi_respuesta() {
        return ti_respuesta;
    }

    public void setTi_respuesta(String ti_respuesta) {
        this.ti_respuesta = ti_respuesta;
    }

    public String getDe_mensaje() {
        return de_mensaje;
    }

    public void setDe_mensaje(String de_mensaje) {
        this.de_mensaje = de_mensaje;
    }

    public String getDe_contenido() {
        return de_contenido;
    }

    public void setDe_contenido(String de_contenido) {
        this.de_contenido = de_contenido;
    }

}
