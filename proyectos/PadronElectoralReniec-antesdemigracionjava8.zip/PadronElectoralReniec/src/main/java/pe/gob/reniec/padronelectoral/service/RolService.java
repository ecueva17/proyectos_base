/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.service;

import java.io.Serializable;
import java.sql.Connection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import pe.gob.reniec.padronelectoral.dao.RolDao;
import pe.gob.reniec.padronelectoral.entity.Rol;

/**
 *
 * @author Hadassa
 */
@Service
public class RolService implements Serializable {

    @Autowired
    transient RolDao rolDao;

    @Autowired
    private DataSource dataSource;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Connection getConnection() {
        // ....use dataSource to create connection
        return DataSourceUtils.getConnection(dataSource);
    }

    public void setRolDao(RolDao rolDao) {
        this.rolDao = rolDao;
    }
    
    public Rol obtenerRol(String nu_dni){
        
        try {
            return rolDao.obtenerRol(nu_dni);
        } catch (Exception ex) {
            Logger.getLogger(RolService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }

}
