/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class ArchivoGenerado extends Auditoria implements Serializable {

    private String co_proceso_electoral;
    private String us_genera_archivo;
    private String fe_genera_archivo;
    private String de_archivo_generado;
    private String co_continente;
    private String co_pais;
    private String co_departamento;
    private String co_provincia;
    private String co_distrito;
    private String in_imagenes;
    private String de_justificacion;
    private String ca_formatos_generados;
    private String co_mcp;
    private String de_nom_file_mcp;
    private String pass_file;

    public ArchivoGenerado() {

    }

    public ArchivoGenerado(String co_departamento, String co_provincia, String co_distrito, String co_mcp, String co_proceso_electoral) {
        this.co_departamento = co_departamento;
        this.co_provincia = co_provincia;
        this.co_distrito = co_distrito;
        this.co_proceso_electoral = co_proceso_electoral;
        this.co_mcp = co_mcp;
    }

    public ArchivoGenerado(String co_departamento, String co_provincia, String co_distrito, String co_mcp, String co_proceso_electoral, String in_imagenes) {
        this.co_departamento = co_departamento;
        this.co_provincia = co_provincia;
        this.co_distrito = co_distrito;
        this.co_mcp = co_mcp;
        this.co_proceso_electoral = co_proceso_electoral;
        this.in_imagenes = in_imagenes;
    }

    /*public ArchivoGenerado(String co_continente, String co_pais, String co_departamento, String co_provincia, String co_distrito, String co_proceso_electoral, String us_genera_archivo, String de_archivo_generado) {
        this.co_continente= co_continente;
        this.co_pais = co_pais;
        this.co_departamento = co_departamento;
        this.co_provincia = co_provincia;
        this.co_distrito = co_distrito;
        this.co_proceso_electoral = co_proceso_electoral;
        this.us_genera_archivo = us_genera_archivo;
        this.de_archivo_generado = de_archivo_generado;
        this.es_registro = "1";
        this.us_crea_audi = us_genera_archivo;
        this.us_modi_audi = us_genera_archivo;
    }*/

    /*public ArchivoGenerado(String co_continente, String co_pais, String co_departamento, String co_provincia, String co_distrito, String co_proceso_electoral, String us_genera_archivo, String de_archivo_generado, String de_justificacion, String in_imagenes) {
        this.co_continente= co_continente;
        this.co_pais = co_pais;
        this.co_departamento = co_departamento;
        this.co_provincia = co_provincia;
        this.co_distrito = co_distrito;
        this.co_proceso_electoral = co_proceso_electoral;
        this.us_genera_archivo = us_genera_archivo;
        this.de_archivo_generado = de_archivo_generado;
        this.de_justificacion = de_justificacion;
        this.es_registro = "1";
        this.us_crea_audi = us_genera_archivo;
        this.us_modi_audi = us_genera_archivo;
        this.in_imagenes = in_imagenes;
    }*/
    
    public ArchivoGenerado(String co_continente, String co_pais, String co_departamento, String co_provincia, String co_distrito, String co_mcp, 
            String co_proceso_electoral, String us_genera_archivo, String de_archivo_generado, String nom_file_mcp, String de_justificacion, String in_imagenes) {
        this.co_continente= co_continente;
        this.co_pais = co_pais;
        this.co_departamento = co_departamento;
        this.co_provincia = co_provincia;
        this.co_distrito = co_distrito;
        this.co_proceso_electoral = co_proceso_electoral;
        this.us_genera_archivo = us_genera_archivo;
        this.de_archivo_generado = de_archivo_generado;
        this.de_justificacion = de_justificacion;
        this.es_registro = "1";
        this.us_crea_audi = us_genera_archivo;
        this.us_modi_audi = us_genera_archivo;
        this.in_imagenes = in_imagenes;
        this.co_mcp = co_mcp;
        this.de_nom_file_mcp = nom_file_mcp;
    }

    public String getCo_departamento() {
        return co_departamento;
    }

    public void setCo_departamento(String co_departamento) {
        this.co_departamento = co_departamento;
    }

    public String getCo_provincia() {
        return co_provincia;
    }

    public void setCo_provincia(String co_provincia) {
        this.co_provincia = co_provincia;
    }

    public String getCo_distrito() {
        return co_distrito;
    }

    public void setCo_distrito(String co_distrito) {
        this.co_distrito = co_distrito;
    }

    public String getCo_continente() {
        return co_continente;
    }

    public void setCo_continente(String co_continente) {
        this.co_continente = co_continente;
    }

    public String getCo_pais() {
        return co_pais;
    }

    public void setCo_pais(String co_pais) {
        this.co_pais = co_pais;
    }

    public String getCo_proceso_electoral() {
        return co_proceso_electoral;
    }

    public void setCo_proceso_electoral(String co_proceso_electoral) {
        this.co_proceso_electoral = co_proceso_electoral;
    }

    public String getUs_genera_archivo() {
        return us_genera_archivo;
    }

    public void setUs_genera_archivo(String us_genera_archivo) {
        this.us_genera_archivo = us_genera_archivo;
    }

    public String getFe_genera_archivo() {
        return fe_genera_archivo;
    }

    public void setFe_genera_archivo(String fe_genera_archivo) {
        this.fe_genera_archivo = fe_genera_archivo;
    }

    public String getDe_archivo_generado() {
        return de_archivo_generado;
    }

    public void setDe_archivo_generado(String de_archivo_generado) {
        this.de_archivo_generado = de_archivo_generado;
    }

    public String getIn_imagenes() {
        return in_imagenes;
    }

    public void setIn_imagenes(String in_imagenes) {
        this.in_imagenes = in_imagenes;
    }

    public String getDe_justificacion() {
        return de_justificacion;
    }

    public void setDe_justificacion(String de_justificacion) {
        this.de_justificacion = de_justificacion;
    }

    public String getCa_formatos_generados() {
        return ca_formatos_generados;
    }

    public void setCa_formatos_generados(String ca_formatos_generados) {
        this.ca_formatos_generados = ca_formatos_generados;
    }

    public String getCo_mcp() {
        return co_mcp;
    }

    public void setCo_mcp(String co_mcp) {
        this.co_mcp = co_mcp;
    }

    public String getDe_nom_file_mcp() {
        return de_nom_file_mcp;
    }

    public void setDe_nom_file_mcp(String de_nom_file_mcp) {
        this.de_nom_file_mcp = de_nom_file_mcp;
    }

    public String getPass_file() {
        return pass_file;
    }

    public void setPass_file(String pass_file) {
        this.pass_file = pass_file;
    }
}
