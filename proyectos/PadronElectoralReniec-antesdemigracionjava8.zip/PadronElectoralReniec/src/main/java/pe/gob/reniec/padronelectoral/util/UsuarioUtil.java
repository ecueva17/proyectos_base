/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pe.gob.reniec.padronelectoral.util;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import pe.gob.reniec.padronelectoral.entity.Usuario;
import pe.gob.reniec.padronelectoral.service.UsuarioService;

/**
 *
 * @author zmontes
 */
public class UsuarioUtil {

    public static Usuario obtenerUsuarioEnSesion(UsuarioService usuarioService) {
        return usuarioService.consultarUsuario(obtenerUsuarioEnSesion());
    }

    public static String obtenerUsuarioEnSesion() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth.getName();
    }
    
}
