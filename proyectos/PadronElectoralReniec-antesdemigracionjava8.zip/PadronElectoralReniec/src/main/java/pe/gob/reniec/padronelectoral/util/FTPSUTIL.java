/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.apache.commons.net.ftp.FTPSClient;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.util.TrustManagerUtils;

/**
 *
 * @author externo.ecueva
 */
public class FTPSUTIL {
    private static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(FTPSUTIL.class);
    
    private String server;
    private int port;
    private String user;
    private String pass;
    
    private FTPSClient ftpClient;
    
    public FTPSUTIL(String server, int port, String user, String pass) {
        this.server = server;
        this.port = port;
        this.user = user;
        this.pass = pass;
    }
    
    public void conectar() throws IOException {
        this.ftpClient = new FTPSClient("TLSv1", false);
        this.ftpClient.setTrustManager(TrustManagerUtils.getAcceptAllTrustManager());
        this.ftpClient.connect(this.server, this.port);
        if (this.ftpClient.login(this.user, this.pass)) {
            // --- ESTAS TRES LÍNEAS SON CRÍTICAS PARA EVITAR EL ERROR 530 ---
            this.ftpClient.execPBSZ(0);          // Protección de buffer
            this.ftpClient.execPROT("P");        // Canal de datos privado (Cifrado)
            this.ftpClient.enterLocalPassiveMode(); // Modo pasivo para firewalls

            this.ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
        } 
    }
    
    public void desconectar() throws IOException {
        this.ftpClient.logout();
        this.ftpClient.disconnect();
    }

    //@TODO ecueva
    public void subirArchivo(String local, String remoto) throws FileNotFoundException, IOException {
        InputStream fis = null;
        OutputStream os = null;
        try {
            fis = new FileInputStream(local);
            os = this.ftpClient.storeFileStream(remoto);
            ArchivoUtil.copiarStream(fis, os);

        } catch (FileNotFoundException e) {
            throw e;
        } catch (IOException e) {
            throw e;
        } finally {
            try {
                ArchivoUtil.cerrarStreams(fis, os);
                this.ftpClient.completePendingCommand();
            } catch (IOException e) {
                logger.error("Sistema: ", e);
            }
        }
    }
    
    /*public void subirArchivo(String local, String remoto) throws IOException {
        InputStream fis = null;
        try {
            fis = new FileInputStream(local);

            // OPCIÓN A: La más segura en Java 6/Commons Net
            // storeFile cierra el canal de datos y completa el comando internamente.
            boolean success = this.ftpClient.storeFile(remoto, fis);

            if (!success) {
                throw new IOException("El servidor no permitió subir el archivo. Respuesta: " + ftpClient.getReplyString());
            }

        } finally {
            if (fis != null) {
                try { fis.close(); } catch (IOException e) {  }
            }
            // IMPORTANTE: NO llamar a completePendingCommand() aquí si usaste storeFile
        }
    }*/

    public void subirArchivosDeDirectorio(String local, String remoto) throws IOException {

        File directorio = new File(local);
        File[] archivosEnDirectorio = directorio.listFiles();

        if (archivosEnDirectorio != null && archivosEnDirectorio.length > 0) {
            for (File item : archivosEnDirectorio) {
                String remoteFilePath = remoto + item.getName();

                if (item.isFile()) {
                    String localFilePath = item.getAbsolutePath();
                    subirArchivo(localFilePath, remoteFilePath);
                }
            }
        }

    }

    //@TODO ecueva
    public void eliminarArchivosDeDirectorio(String directorio, String excluirExtension) throws IOException {
        FTPFile[] archivosEnDirectorio = ftpClient.listFiles(directorio);

        if (archivosEnDirectorio != null && archivosEnDirectorio.length > 0) {
            for (FTPFile item : archivosEnDirectorio) {
                String nombreDeItem = item.getName();
                if (nombreDeItem.equals(".") || nombreDeItem.equals("..")) {
                    continue;
                }
                if (item.isFile()) {
                    if(!(nombreDeItem.toLowerCase().endsWith(excluirExtension.toLowerCase()))){
                        ftpClient.deleteFile(directorio + "/" + nombreDeItem);
                    }
                }
            }
        }
    }
    /*public void eliminarArchivosDeDirectorio(String directorio) throws IOException {
        // listNames() devuelve solo los nombres de los archivos (String)
        String[] nombresArchivos = ftpClient.listNames(directorio);

        if (nombresArchivos != null) {
            for (String nombre : nombresArchivos) {
                // En listNames a veces vienen solo nombres, a veces rutas relativas
                if (!nombre.equals(".") && !nombre.equals("..")) {
                    // Intentar borrar (si es directorio, deleteFile simplemente fallará o devolverá false)
                    ftpClient.deleteFile(directorio + "/" + nombre);
                }
            }
        }
    }*/

    public void crearDirectorio(String directorio) throws IOException {
        String carpetas[] = directorio.split("/");
        String directorioACrear = "";
        for (String carpeta : carpetas) {
            directorioACrear += "/" + carpeta;
            this.ftpClient.makeDirectory(directorioACrear);
        }

    }

    public void descargarArchivo(String remoto, OutputStream os) throws IOException {
        InputStream is = null;
        try {
            is = ftpClient.retrieveFileStream(remoto);
            ArchivoUtil.copiarStream(is, os);

        } catch (IOException e) {
            throw e;
        } finally {
            try {
                ArchivoUtil.cerrarStreams(is, os);
                this.ftpClient.completePendingCommand();
            } catch (IOException e) {
                logger.error("Sistema: ", e);
            }
        }
    }

    public void descargarArchivosDeVariosDirectorios(String remoto, String[] directorios, ZipOutputStream zos) throws IOException {

        try {
            for (String directorio : directorios) {
                ZipEntry zipEntry = new ZipEntry(directorio + "/");
                zos.putNextEntry(zipEntry);
                zos.closeEntry();
                descargarArchivosDeUnDirectorio(remoto, directorio, zos);
            }
        } catch (IOException e) {
            throw e;
        } finally {
            try {
                ArchivoUtil.cerrarOutputStream(zos);
            } catch (IOException e) {
                logger.error("Sistema: ", e);
            }
        }
    }

    public void descargarArchivosDeUnDirectorio(String remoto, String directorio, ZipOutputStream zos) throws IOException {

        FTPFile[] archivosEnDirectorio = ftpClient.listFiles(remoto + "/" + directorio);
        InputStream is = null;

        if (archivosEnDirectorio != null && archivosEnDirectorio.length > 0) {
            for (FTPFile item : archivosEnDirectorio) {
                String nombreDeItem = item.getName();
                if (nombreDeItem.equals(".") || nombreDeItem.equals("..")) {
                    continue;
                }
                if (item.isFile()) {
                    try {
                        is = ftpClient.retrieveFileStream(remoto + "/" + directorio + "/" + nombreDeItem);

                        ZipEntry zipEntry = new ZipEntry(directorio + "/" + nombreDeItem);
                        zos.putNextEntry(zipEntry);
                        ArchivoUtil.copiarStream(is, zos);

                    } catch (IOException e) {
                        throw e;
                    } finally {
                        try {
                            ArchivoUtil.cerrarStreams(is, zos);
                            this.ftpClient.completePendingCommand();
                        } catch (IOException e) {
                            logger.error("Sistema: ", e);
                        }
                    }

                }
            }

        }
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
