/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.padronelectoral.entity.ArchivoGenerado;
import pe.gob.reniec.padronelectoral.entity.UbigeoPorProceso;
import pe.gob.reniec.padronelectoral.util.NombreDeTablasUtil;

/**
 *
 * @author Hadassa
 */
@Repository
public interface ArchivoGeneradoDao {

    @Select("SELECT co_continente, co_pais, co_departamento, co_provincia, co_distrito, CO_MCP, co_proceso_electoral, in_imagenes, ca_formatos_generados"
            + " FROM "+ NombreDeTablasUtil.Archivo_generado
            + " WHERE co_proceso_electoral=#{archivoGenerado.co_proceso_electoral} AND co_continente = '92' AND co_pais = '33'"
            + " AND co_departamento=#{archivoGenerado.co_departamento} AND co_provincia=#{archivoGenerado.co_provincia} AND co_distrito=#{archivoGenerado.co_distrito}"
            + " AND CO_MCP=#{archivoGenerado.co_mcp}"
            + " AND es_registro = '1' ")
    public ArchivoGenerado consultarArchivoGenerado(@Param("archivoGenerado") ArchivoGenerado archivoGenerado) throws Exception;

    @Select("SELECT co_continente, co_pais, co_departamento, co_provincia, co_distrito, CO_MCP, co_proceso_electoral, us_genera_archivo, fe_genera_archivo, de_archivo_generado"
            + " FROM "+ NombreDeTablasUtil.Archivo_generado
            + " WHERE co_proceso_electoral=#{archivoGenerado.co_proceso_electoral} AND co_continente = '92' AND co_pais = '33'"
            + " AND co_departamento=#{archivoGenerado.co_departamento} AND co_provincia=#{archivoGenerado.co_provincia} AND co_distrito=#{archivoGenerado.co_distrito}"
            + " AND CO_MCP=#{archivoGenerado.co_mcp}"
            + " AND es_registro = '1' AND (in_imagenes=#{archivoGenerado.in_imagenes} OR ca_formatos_generados > 1)")
    public ArchivoGenerado consultarArchivoGeneradoIndicandoImagenes(@Param("archivoGenerado") ArchivoGenerado archivoGenerado) throws Exception;
    
    @Select("INSERT INTO " + NombreDeTablasUtil.Archivo_generado +" (co_continente, co_pais, co_departamento, co_provincia, co_distrito, CO_MCP, co_proceso_electoral, us_genera_archivo, fe_genera_archivo, de_archivo_generado, "
            + " DE_NOM_ARCHIVO_MCP, es_registro, us_crea_audi, fe_crea_audi, in_imagenes, ca_formatos_generados, DE_CLAVE_ARCH_MCP) "
            + " VALUES (#{archivoGenerado.co_continente}, #{archivoGenerado.co_pais}, #{archivoGenerado.co_departamento}, #{archivoGenerado.co_provincia}, #{archivoGenerado.co_distrito},"
            + " #{archivoGenerado.co_mcp},"
            + " #{archivoGenerado.co_proceso_electoral}, #{archivoGenerado.us_genera_archivo}, SYSDATE, #{archivoGenerado.de_archivo_generado},"
            + " #{archivoGenerado.de_nom_file_mcp}, #{archivoGenerado.es_registro}, #{archivoGenerado.us_crea_audi}, SYSDATE, #{archivoGenerado.in_imagenes}, #{archivoGenerado.ca_formatos_generados},  #{archivoGenerado.pass_file}) ")
    public void registrarArchivoGenerado(@Param("archivoGenerado") ArchivoGenerado archivoGenerado) throws Exception;

    @Select("SELECT DISTINCT(t.co_departamento),\n"
            + " (SELECT u.NO_DEPARTAMENTO"
            + "     FROM " + NombreDeTablasUtil.Ubigeo + " u"
            + "     WHERE u.CO_CONTINENTE_RENIEC = t.co_continente AND u.CO_PAIS_RENIEC = t.co_pais\n"
            + "     AND u.CO_DEPARTAMENTO_RENIEC = t.co_departamento AND rownum = 1) no_departamento\n"
            + " FROM " + NombreDeTablasUtil.Archivo_generado + " t"
            + " WHERE t.co_proceso_electoral = #{co_proceso_electoral} AND t.co_continente = #{co_continente} AND t.co_pais = #{co_pais} AND t.es_registro = '1'\n"
            + " ORDER BY no_departamento")
    public List<UbigeoPorProceso> listarDepartamentosGenerados(
            @Param("co_proceso_electoral") String co_proceso_electoral,
            @Param("co_continente") String co_continente,
            @Param("co_pais") String co_pais
    ) throws Exception;
    
    @Select("SELECT DISTINCT(t.co_provincia),\n"
            + " (SELECT u.NO_PROVINCIA"
            + "     FROM " + NombreDeTablasUtil.Ubigeo + " u"
            + "     WHERE u.CO_CONTINENTE_RENIEC = t.co_continente AND u.CO_PAIS_RENIEC = t.co_pais\n"
            + "     AND u.CO_DEPARTAMENTO_RENIEC = t.co_departamento AND u.CO_PROVINCIA_RENIEC = t.co_provincia AND rownum = 1) no_provincia\n"
            + " FROM " + NombreDeTablasUtil.Archivo_generado + " t"
            + " WHERE t.co_proceso_electoral = #{co_proceso_electoral} AND t.co_continente = #{co_continente} AND t.co_pais = #{co_pais}"
            + " AND t.co_departamento = #{co_departamento} AND t.es_registro = '1'"
            + " ORDER BY no_provincia")
    public List<UbigeoPorProceso> listarProvinciasGeneradas(
            @Param("co_proceso_electoral") String co_proceso_electoral,
            @Param("co_continente") String co_continente,
            @Param("co_pais") String co_pais,
            @Param("co_departamento") String co_departamento
    ) throws Exception;
    
    @Select("SELECT DISTINCT(t.co_distrito),\n"
            + " (SELECT u.NO_DISTRITO FROM " + NombreDeTablasUtil.Ubigeo + " u"
            + "     WHERE u.CO_CONTINENTE_RENIEC = t.co_continente AND u.CO_PAIS_RENIEC = t.co_pais\n"
            + "     AND u.CO_DEPARTAMENTO_RENIEC = t.co_departamento AND u.CO_PROVINCIA_RENIEC = t.co_provincia and u.CO_DISTRITO_RENIEC = t.co_distrito\n"
            + "     AND rownum = 1) no_distrito\n"
            + " FROM " + NombreDeTablasUtil.Archivo_generado + " t"
            + " WHERE t.co_proceso_electoral = #{co_proceso_electoral} AND t.co_continente = '92' AND t.co_pais = '33'"
            + " AND t.co_departamento = #{co_departamento} AND t.co_provincia = #{co_provincia} AND t.es_registro = '1'"
            + " ORDER BY no_distrito")
    public List<UbigeoPorProceso> listarDistritosGenerados(
            @Param("co_proceso_electoral") String co_proceso_electoral,
            @Param("co_continente") String co_continente,
            @Param("co_pais") String co_pais,
            @Param("co_departamento") String co_departamento,
            @Param("co_provincia") String co_provincia
    ) throws Exception;
    
    @Select("SELECT DISTINCT(t.CO_MCP),\n"
            + " (SELECT u.NO_MUNI_CENTRO_POBLADO FROM " + NombreDeTablasUtil.Ubigeo + " u"
            + "     WHERE u.CO_CONTINENTE_RENIEC = t.co_continente AND u.CO_PAIS_RENIEC = t.co_pais\n"
            + "     AND u.CO_DEPARTAMENTO_RENIEC = t.co_departamento AND u.CO_PROVINCIA_RENIEC = t.co_provincia and u.CO_DISTRITO_RENIEC = t.co_distrito\n"
            + "     AND u.CO_MUNI_CENTRO_POBLADO = t.CO_MCP "
            + "     AND rownum = 1) no_mcp\n"
            + " FROM " + NombreDeTablasUtil.Archivo_generado + " t"
            + " WHERE t.co_proceso_electoral = #{co_proceso_electoral} AND t.co_continente = '92' AND t.co_pais = '33'"
            + " AND t.co_departamento = #{co_departamento} AND t.co_provincia = #{co_provincia} AND t.CO_DISTRITO = #{co_distrito} AND t.es_registro = '1'"
            + " ORDER BY no_mcp")
    public List<UbigeoPorProceso> listarMCPGenerados(
            @Param("co_proceso_electoral") String co_proceso_electoral,
            @Param("co_continente") String co_continente,
            @Param("co_pais") String co_pais,
            @Param("co_departamento") String co_departamento,
            @Param("co_provincia") String co_provincia,
            @Param("co_distrito") String co_distrito
    ) throws Exception;
    
    @Update("UPDATE " + NombreDeTablasUtil.Archivo_generado +" SET ca_formatos_generados = ca_formatos_generados + 1, DE_CLAVE_ARCH_MCP = #{archivoGenerado.pass_file}, US_MODI_AUDI = #{archivoGenerado.us_crea_audi}, FE_MODI_AUDI = SYSDATE "
            + " WHERE co_proceso_electoral=#{archivoGenerado.co_proceso_electoral} AND co_continente = '92' AND co_pais = '33' AND co_departamento=#{archivoGenerado.co_departamento} "
            + " AND co_provincia=#{archivoGenerado.co_provincia} AND co_distrito=#{archivoGenerado.co_distrito}"
            + " AND CO_MCP=#{archivoGenerado.co_mcp}"
            + " AND es_registro = '1' ")
    public void actualizarCaFormatosGenerados(@Param("archivoGenerado") ArchivoGenerado archivoGenerado) throws Exception;
    
    @Select("select" +
            " IDOLPI.PK_GP_UTIL.FN_GET_CLAVE_AES256(#{nombre_file})" +
            " from dual ")
    public String obtenerPasswordArchivo(
            @Param("nombre_file") String nombreFile
    );
    
    @Select("select" +
            " DE_CLAVE_ARCH_MCP " +
            " from " + NombreDeTablasUtil.Archivo_generado +
            " WHERE co_proceso_electoral=#{co_proceso_electoral} AND co_continente = #{co_continente} AND co_pais = #{co_pais} AND co_departamento=#{co_departamento} " +
            " AND co_provincia=#{co_provincia} AND co_distrito=#{co_distrito}" +
            " AND CO_MCP=#{co_mcp}")
    public String obtenerClaveArchivoGenerado(
            @Param("co_proceso_electoral") String co_proceso_electoral,
            @Param("co_continente") String co_continente,
            @Param("co_pais") String co_pais,
            @Param("co_departamento") String co_departamento,
            @Param("co_provincia") String co_provincia,
            @Param("co_distrito") String co_distrito,
            @Param("co_mcp") String co_mcp
    );
}
