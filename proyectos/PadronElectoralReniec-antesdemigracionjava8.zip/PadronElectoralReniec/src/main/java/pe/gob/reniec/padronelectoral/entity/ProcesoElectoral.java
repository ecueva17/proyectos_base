/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class ProcesoElectoral extends Auditoria implements Serializable {

    private String co_proceso_electoral;
    private String de_proceso_electoral;
    private Date fe_realizacion;

    public ProcesoElectoral(String co_proceso_electoral, String de_proceso_electoral, String co_usuario, boolean val) {
        this.co_proceso_electoral = co_proceso_electoral;
        this.de_proceso_electoral = de_proceso_electoral;
        this.es_registro = "1";
        this.us_crea_audi = co_usuario;
        this.us_modi_audi = co_usuario;
    }

    public ProcesoElectoral(String co_proceso_electoral, String de_proceso_electoral, String co_usuario, String val) {
        this.co_proceso_electoral = co_proceso_electoral;
        this.de_proceso_electoral = de_proceso_electoral;
        this.us_crea_audi = co_usuario;
    }

    public ProcesoElectoral(String co_proceso_electoral) {
        this.co_proceso_electoral = co_proceso_electoral;
    }

    public ProcesoElectoral() {
    }

    public String getCo_proceso_electoral() {
        return co_proceso_electoral;
    }

    public void setCo_proceso_electoral(String co_proceso_electoral) {
        this.co_proceso_electoral = co_proceso_electoral;
    }

    public String getDe_proceso_electoral() {
        return de_proceso_electoral.toUpperCase();
    }

    public void setDe_proceso_electoral(String de_proceso_electoral) {
        this.de_proceso_electoral = de_proceso_electoral;
    }

    public Date getFe_realizacion() {
        return fe_realizacion;
    }
    
    public String getFe_realizacionToString() {
        if (fe_realizacion == null) {
            return "";
        }
        SimpleDateFormat formateador = new SimpleDateFormat("dd 'DE' MMMM 'DEL' yyyy", new Locale("es", "ES"));
        return formateador.format(fe_realizacion).toUpperCase();
    }

    public void setFe_realizacion(Date fe_realizacion) {
        this.fe_realizacion = fe_realizacion;
    }

    public String toString(){
        return co_proceso_electoral + " - " + de_proceso_electoral + " - " + fe_realizacion;
    }
}
