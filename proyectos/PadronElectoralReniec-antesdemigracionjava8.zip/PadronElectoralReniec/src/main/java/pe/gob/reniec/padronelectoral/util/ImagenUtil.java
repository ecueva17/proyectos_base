/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.util;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import javax.imageio.ImageIO;
import org.apache.log4j.Logger;

/**
 *
 * @author eibanez
 */
public final class ImagenUtil {

    private static final Logger logger = Logger.getLogger(ImagenUtil.class);

    public static byte[] agregarMarcaDeAguaReniec(byte[] byteImage) {
        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(byteImage);
            BufferedImage bufferedImage = ImageIO.read(bais);
            int centerX = bufferedImage.getWidth() / 2;
            int centerY = bufferedImage.getHeight() / 2;
            String fecha = FechaUtil.formatearFecha(new Date(), "dd-MM-yyyy HH:mm:ss");

            agregarMarcaDeAguaTexto(bufferedImage, fecha, 13, Color.black, ConstantesUtil.POSICICON_SaN, 80, -50, centerX, centerY);
            agregarMarcaDeAguaTexto(bufferedImage, "RENIEC", 20, Color.black, 0, 0, -95, centerX, centerY);
            agregarMarcaDeAguaTexto(bufferedImage, "RENIEC © 2015", 26, Color.black, ConstantesUtil.POSICICON_NOaSE, 0, 0, centerX, centerY);
            agregarMarcaDeAguaTexto(bufferedImage, UsuarioUtil.obtenerUsuarioEnSesion(), 20, Color.red, ConstantesUtil.POSICICON_NOaSE, 0, 26, centerX, centerY);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, "gif", baos);
            baos.flush();
            byte[] imagenTrabajada = baos.toByteArray();
            baos.close();

            return imagenTrabajada;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void agregarMarcaDeAguaTexto(
            BufferedImage sourceImage,
            String text,
            int fontSize,
            Color fontColor,
            double posRotate,
            double posTranslateX,
            double posTranslateY,
            int centerX,
            int centerY) {

        Graphics2D g2d = (Graphics2D) sourceImage.getGraphics();

        AlphaComposite alphaChannel = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f);
        g2d.setComposite(alphaChannel);
        g2d.setColor(fontColor);
        g2d.setFont(new Font("Arial", Font.BOLD, fontSize));

        FontMetrics fontMetrics = g2d.getFontMetrics();
        Rectangle2D rect = fontMetrics.getStringBounds(text, g2d);
        centerX = centerX - ((int) rect.getWidth()) / 2;

        AffineTransform at = new AffineTransform();
        at.translate(posTranslateX, posTranslateY);
        at.rotate(posRotate, sourceImage.getWidth() / 2.0, sourceImage.getHeight() / 2.0);

        g2d.setTransform(at);
        g2d.drawString(text, centerX, centerY);
        g2d.dispose();

    }

    public static byte[] escalar(byte[] fileData, int height) {
        ByteArrayInputStream in = new ByteArrayInputStream(fileData);
        try {
            BufferedImage img = ImageIO.read(in);
            int width = obtenerAnchoProporcional(img, height);
            Image scaledImage = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            BufferedImage imageBuff = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            imageBuff.getGraphics().drawImage(scaledImage, 0, 0, new Color(0, 0, 0), null);

            ByteArrayOutputStream buffer = new ByteArrayOutputStream();

            ImageIO.write(imageBuff, "jpg", buffer);

            return buffer.toByteArray();
        } catch (IOException e) {
            logger.error("Sistema: ", e);
        } catch (Exception e) {
            logger.error("Sistema: ", e);
        }
        return fileData;
    }

    public static Image escalar(Image imagen, int height) {
        try {
            BufferedImage image = (BufferedImage) imagen;
            BufferedImage biDestino = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);

            for (int x = 0; x < image.getWidth(); x++) {
                for (int y = 0; y < image.getHeight(); y++) {
                    Color c1 = new Color(image.getRGB(x, y));
                    int med = (c1.getRed() + c1.getGreen() + c1.getBlue()) / 3;
                    biDestino.setRGB(x, y, new Color(med, med, med).getRGB());
                }
            }

            int width = obtenerAnchoProporcional(biDestino, height);
            return biDestino.getScaledInstance(width, height, Image.SCALE_SMOOTH);

        } catch (Exception e) {
            logger.error("Sistema: ", e);
            return null;
        }
    }

    public static int obtenerAnchoProporcional(BufferedImage imagen, int altoProporcional) {
        int ancho = imagen.getWidth();
        int alto = imagen.getHeight();
        return ancho * altoProporcional / alto;
    }

}
