/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.controllers;

import com.itextpdf.text.DocumentException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import pe.gob.reniec.padronelectoral.entity.ArchivoGenerado;
import pe.gob.reniec.padronelectoral.entity.Modulo;
import pe.gob.reniec.padronelectoral.entity.PadronElectoral;
import pe.gob.reniec.padronelectoral.entity.ProcesoElectoral;
import pe.gob.reniec.padronelectoral.entity.RespuestaJSON;
import pe.gob.reniec.padronelectoral.entity.Rol;
import pe.gob.reniec.padronelectoral.service.ArchGenHistoricoService;
import pe.gob.reniec.padronelectoral.service.ArchivoGeneradoService;
import pe.gob.reniec.padronelectoral.service.ModuloService;
import pe.gob.reniec.padronelectoral.service.ParametroDetalleService;
import pe.gob.reniec.padronelectoral.service.ProcesoElectoralService;
import pe.gob.reniec.padronelectoral.service.RolService;
import pe.gob.reniec.padronelectoral.util.ArchivoUtil;
import pe.gob.reniec.padronelectoral.entity.UbigeoPorProceso;
import pe.gob.reniec.padronelectoral.entity.Usuario;
import pe.gob.reniec.padronelectoral.service.PadronElectoralService;
import pe.gob.reniec.padronelectoral.service.UbigeoPorProcesoService;
import pe.gob.reniec.padronelectoral.service.UsuarioService;
import pe.gob.reniec.padronelectoral.util.ConstantesUtil;
import pe.gob.reniec.padronelectoral.util.FTPSUTIL;
//import pe.gob.reniec.padronelectoral.util.FTPUtil;
import pe.gob.reniec.padronelectoral.util.FechaUtil;
//import pe.gob.reniec.padronelectoral.util.LFTPUTIL;
import pe.gob.reniec.padronelectoral.util.ReporteUtil;
import pe.gob.reniec.padronelectoral.util.UsuarioUtil;
import pe.gob.reniec.padronelectoral.util.Util;

/**
 *
 * @author ydelatorre
 */
@Controller
@Scope("session")
public class InicioController implements Serializable {

    final static Logger logger = Logger.getLogger(InicioController.class);

    @Autowired
    ArchivoGeneradoService archivoGeneradoService;
    @Autowired
    ArchGenHistoricoService archGenHistoricoService;
    @Autowired
    ProcesoElectoralService procesoElectoralService;
    @Autowired
    transient ModuloService moduloService;
    @Autowired
    transient UsuarioService usuarioService;
    @Autowired
    transient ParametroDetalleService parametroDetalleService;
    @Autowired
    RolService rolService;
    @Autowired
    UbigeoPorProcesoService ubigeoPorProcesoService;
    
    @Autowired
    PadronElectoralService padronElectoralService;

    //private static final String RUTA_PADRON = "D:\\ftpdata\\lpi\\";//TEMPORAL:PC
    //produccion
    private static final String RUTA_PADRON = "/data/";
    //desarrollo
    //private static final String RUTA_PADRON = "/data/lpi/";
    private static final String RUTA_LOGO = "/resources/images/logo_reniec.jpg";
    private static final String RUTA_FONDO = "/resources/images/logo_fondo.jpg";
    private static final String RUTA_REPORTE = "/resources/reportes/";
    private ProcesoElectoral procesoElectoral;
    private Usuario usuarioActual = null;
    private List<List<String>> resultadoGeneracion = new ArrayList<List<String>>();
    List<UbigeoPorProceso> ubigeos = new ArrayList<UbigeoPorProceso>();
    private boolean hayErrorEnUbigeos;
    private int contadorUbigeosProcesados;
    private int contadorUbigeosErroneos;
    private String ubigeoProcesando = "";

    @RequestMapping(value = {"", "/", "inicio"}, method = RequestMethod.GET)
    public ModelAndView navegarInicio(ModelMap map, HttpServletRequest request) {

        this.usuarioActual = UsuarioUtil.obtenerUsuarioEnSesion(usuarioService);
        Rol rol = rolService.obtenerRol(usuarioActual.getNu_dni());
        List<Modulo> listaMenu = moduloService.obtenerListaPorRol(rol.getCo_rol());

        ModelAndView mv = new ModelAndView("index");
        mv.addObject("fechaActual", FechaUtil.obtenerFechaActual());
        mv.addObject("usuario", usuarioActual.getNu_dni());
        mv.addObject("rol", rol.getDe_rol());
        mv.addObject("listaMenu", listaMenu);

        return mv;
    }

    @RequestMapping(value = {"navegarGenerarPadron"}, method = RequestMethod.GET)
    public String navegarGenerarPadron(ModelMap map, HttpServletRequest request) {
        return "generarPadron";
    }

    @RequestMapping(value = {"navegarCambiarClave"}, method = RequestMethod.GET)
    public String navegarCambiarClave(ModelMap map, HttpServletRequest request) {
        return "cambiarClave";
    }

    @RequestMapping(value = "/verificarClave", method = RequestMethod.POST)
    public @ResponseBody
    RespuestaJSON verificarClave(@RequestParam String de_clave) {
        String ti_respuesta = "success";
        String de_mensaje = "Todo OK";
        String de_contenido = "Todo se realizó correctamente.";

        try {
            if (!usuarioActual.getDe_password().equals(DigestUtils.md5Hex(de_clave))) {
                ti_respuesta = "danger";
                de_mensaje = "La clave ingresada no es la actual.";
                de_contenido = "La clave ingresada no es la actual";
            }

        } catch (Exception e) {
            ti_respuesta = "danger";
            de_mensaje = "Error al intentar conectar con base de datos";
            de_contenido = e.getLocalizedMessage();
            logger.error("Sistema: ", e);
        }
        RespuestaJSON respuesta = new RespuestaJSON(ti_respuesta, de_mensaje, de_contenido);
        return respuesta;
    }

    @RequestMapping(value = "/accionCambiarClave", method = RequestMethod.POST)
    public @ResponseBody
    RespuestaJSON accionCambiarClave(@RequestParam String de_clave) {
        String ti_respuesta;
        String de_mensaje;
        try {
            String nueva_clave = DigestUtils.md5Hex(de_clave);
            usuarioService.actualizarPassword(usuarioActual.getNu_dni(), nueva_clave);
            ti_respuesta = "success";
            de_mensaje = "Se actualizó la clave correctamente.";
        } catch (Exception e) {
            ti_respuesta = "danger";
            de_mensaje = "Error al intentar conectar con base de datos";
            logger.error("Sistema: ", e);
        }
        RespuestaJSON respuesta = new RespuestaJSON(ti_respuesta, de_mensaje, "");
        return respuesta;
    }

    @RequestMapping(value = "/obtenerDepartamentosGenerados", method = RequestMethod.GET)
    public @ResponseBody
    List<UbigeoPorProceso> obtenerDepartamentosGenerados(@RequestParam String codCont, @RequestParam String codPais) {
        try {
            this.procesoElectoral = obtenerProcesoActivo();
            return archivoGeneradoService.listarDepartamentosGenerados(this.procesoElectoral.getCo_proceso_electoral(), codCont, codPais);
        } catch (Exception e) {
            logger.error("Error al conectar con base de datos, obtenerDepartamentos.", e);
        }
        return null;
    }

    @RequestMapping(value = "/obtenerProvinciasGeneradas", method = RequestMethod.GET)
    public @ResponseBody
    List<UbigeoPorProceso> obtenerProvinciasGeneradas(@RequestParam String codCont, @RequestParam String codPais, @RequestParam String codDep) {
        try {
            return archivoGeneradoService.listarProvinciasGeneradas(this.procesoElectoral.getCo_proceso_electoral(), codCont, codPais, codDep);
        } catch (Exception e) {
            logger.error("Error al conectar con base de datos, obtenerDepartamentos.", e);
        }
        return null;
    }

    @RequestMapping(value = "/obtenerDistritosGenerados", method = RequestMethod.GET)
    public @ResponseBody
    List<UbigeoPorProceso> obtenerDistritosGenerados(@RequestParam String codCont, @RequestParam String codPais, @RequestParam String codDep, @RequestParam String codPro) {
        try {
            return archivoGeneradoService.listarDistritosGenerados(this.procesoElectoral.getCo_proceso_electoral(), codCont, codPais, codDep, codPro);
        } catch (Exception e) {
            logger.error("Error al conectar con base de datos, obtenerDepartamentos.", e);
        }
        return null;
    }
    
    @RequestMapping(value = "/obtenerMCPGenerados", method = RequestMethod.GET)
    public @ResponseBody
    List<UbigeoPorProceso> obtenerMCPGenerados(@RequestParam String codCont, @RequestParam String codPais, 
            @RequestParam String codDep, @RequestParam String codPro, @RequestParam String codDis) {
        try {
            return archivoGeneradoService.listarMCPGenerados(this.procesoElectoral.getCo_proceso_electoral(), codCont, codPais, codDep, codPro, codDis);
        } catch (Exception e) {
            logger.error("Error al conectar con base de datos, obtenerDepartamentos.", e);
        }
        return null;
    }

    @RequestMapping("/accionGenerarPadron")
    public @ResponseBody
    RespuestaJSON accionGenerarPadron(@RequestParam(value = "de_justificacion") String de_justificacion,
            @RequestParam(value = "in_imagenes", required = false) boolean in_imagenes,
            HttpServletRequest request, HttpServletResponse response) {

        if (this.ubigeos.isEmpty()) {
            logger.error(usuarioActual.getNu_dni() + ": No se pudo generar, debe cargar archivo de ubigeos a generar.");
            return new RespuestaJSON("danger", "No se pudo generar, debe cargar archivo de ubigeos a generar.");
        }

        try {
            String inProcesando = usuarioService.obtenerIndicadorProcesando(usuarioActual.getNu_dni());
            if (inProcesando != null && inProcesando.equalsIgnoreCase("1")) {
                logger.error(usuarioActual.getNu_dni() + ": No se pudo generar, el usuario ya esta generando en otro lugar.");
                return new RespuestaJSON("danger", "No se pudo generar, el usuario ya esta generando en otro lugar.");
            } else {
                usuarioService.actualizarIndicadorProcesando(usuarioActual.getNu_dni(), "1");
            }
        } catch (Exception e) {
            logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
        }

        RespuestaJSON respuesta = new RespuestaJSON("success", "Se generaron los LPI correctamente.");
        ServletContext sc = request.getSession(false).getServletContext();
        //@TODO ecueva
        //FTPUtil ftpUtil = null;
        FTPSUTIL ftpUtil = null;
        //LFTPUTIL ftpUtil = null;
        Connection conn = null;

        List<String> plantillas = new ArrayList<String>();
        plantillas.add(sc.getRealPath(RUTA_REPORTE + "reportPadronElectoral.jasper"));
        /*plantillas.add(sc.getRealPath(RUTA_REPORTE + "reportPadronElectoral.jasper"));
        plantillas.add(sc.getRealPath(RUTA_REPORTE + "reportPadronElectoral_sinimg_restrOA.jasper"));
        plantillas.add(sc.getRealPath(RUTA_REPORTE + "reportPadronElectoral_sinimg_restrDNI.jasper"));
        plantillas.add(sc.getRealPath(RUTA_REPORTE + "reportPadronElectoral_restricciones.jasper"));*/

        this.procesoElectoral = obtenerProcesoActivo();
        resultadoGeneracion = new ArrayList<List<String>>();
        hayErrorEnUbigeos = false;
        boolean hayErrorEnUbigeo;
        String mensajeErrorEnUbigeo = "";

        String carpetaLocal = RUTA_PADRON + "pdf-mcp/";
        String carpetaRemota = "/padron/";
        String nombreArchivoSinExtension;
        String subDirectorio;

        Map parametrosReporte = new HashMap();
        parametrosReporte.put("FE_REALIZACION", this.procesoElectoral.getFe_realizacionToString());
        parametrosReporte.put("DE_PROCESO", this.procesoElectoral.getDe_proceso_electoral());
        parametrosReporte.put("CO_PROCESO", this.procesoElectoral.getCo_proceso_electoral());
        parametrosReporte.put("foto_ancho", ConstantesUtil.FOTO_CIUDADANO_PDF_WIDTH);
        parametrosReporte.put("foto_alto", ConstantesUtil.FOTO_CIUDADANO_PDF_HEIGHT);
        parametrosReporte.put("LOGO_RENIEC", sc.getRealPath(RUTA_LOGO));
        parametrosReporte.put("FONDO_RENIEC", sc.getRealPath(RUTA_FONDO));

        String inImagenes = (in_imagenes) ? "1" : "0";
        Long generandoUbigeo = 0L;
        contadorUbigeosProcesados = 0;
        contadorUbigeosErroneos = 0;

        try {
            //@TODO ecueva
            //ftpUtil = new FTPUtil(parametroDetalleService.obtenerParametroPorDescripcion("02", "URL").getDe_valor(),
            ftpUtil = new FTPSUTIL(parametroDetalleService.obtenerParametroPorDescripcion("06", "URL").getDe_valor(),
            //ftpUtil = new LFTPUTIL(parametroDetalleService.obtenerParametroPorDescripcion("02", "URL").getDe_valor(),
                    21,
                    parametroDetalleService.obtenerParametroPorDescripcion("06", "USUARIO").getDe_valor(),
                    parametroDetalleService.obtenerParametroPorDescripcion("06", "CLAVE").getDe_valor());
            conn = parametroDetalleService.getConnection();

        } catch (Exception e) {
            logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
            return new RespuestaJSON("danger", "Error al intentar conectar con base de datos", "");
        }

        for (UbigeoPorProceso ubigeo : this.ubigeos) {
            ubigeoProcesando = ubigeo.getCo_departamento() + ubigeo.getCo_provincia() + ubigeo.getCo_distrito() + ubigeo.getCo_mcp();
            hayErrorEnUbigeo = false;
            mensajeErrorEnUbigeo = "";
        
            parametrosReporte.put("CO_DEPARTAMENTO", ubigeo.getCo_departamento());
            parametrosReporte.put("CO_PROVINCIA", ubigeo.getCo_provincia());
            parametrosReporte.put("CO_DISTRITO", ubigeo.getCo_distrito());
            parametrosReporte.put("CO_MUNI_CP", ubigeo.getCo_mcp());
            parametrosReporte.put("DE_DEPARTAMENTO", ubigeo.getNo_departamento());
            parametrosReporte.put("DE_PROVINCIA", ubigeo.getNo_provincia());
            parametrosReporte.put("DE_DISTRITO", ubigeo.getNo_distrito());
            parametrosReporte.put("DE_MUNI_CP", ubigeo.getNo_mcp());

            nombreArchivoSinExtension = "PE-CP" + ubigeo.getCo_departamento() + ubigeo.getCo_provincia() + ubigeo.getCo_distrito() + ubigeo.getCo_mcp();
            subDirectorio = ubigeo.getCo_departamento() + "/" + ubigeo.getCo_provincia() + "/" + ubigeo.getCo_distrito() + "/" + ubigeo.getCo_mcp() + "/";
            String rutaDirectorioLocal = carpetaLocal + subDirectorio;
            String nombreArchivoPdf = nombreArchivoSinExtension + ConstantesUtil.EXTENSION_PDF;
            String password = "";
            
            try {
                password = archivoGeneradoService.getPasswordArchivo(nombreArchivoSinExtension);
            } catch (Exception e) {
                logger.error(usuarioActual.getNu_dni() + ": Sistema: (Error al obtener password 256 de base de datos) ", e);
            }

            try {
                generandoUbigeo = ubigeoPorProcesoService.obtenerCantidadRegistrosConEstadoGenerandoEnUbigeo(ubigeo);
                if (generandoUbigeo == 0) {
                    ubigeo.setEs_registro("2");
                    ubigeoPorProcesoService.actualizarEstado(ubigeo);

                    ReporteUtil reporteUtil = new ReporteUtil(conn, parametrosReporte, rutaDirectorioLocal, nombreArchivoPdf);

                    if (in_imagenes) {
                        logger.info(usuarioActual.getNu_dni() + ": crear c/img :" + nombreArchivoSinExtension);
                    } else {
                        logger.info(usuarioActual.getNu_dni() + ": crear s/img :" + nombreArchivoSinExtension);
                        rutaDirectorioLocal = carpetaLocal + "sin_imagenes/" + subDirectorio;
                        reporteUtil.getParametros().put("LOGO_RENIEC", "");
                        reporteUtil.getParametros().put("FONDO_RENIEC", "");
                        reporteUtil.setDirectorio(rutaDirectorioLocal);
                    }
                    
                    
                    //System.out.println(usuarioActual.getNu_dni() + ": se establecieron las rutas");
                    //logger.info(usuarioActual.getNu_dni() + ": se establecieron las rutas");
                    crearReportesEnDirectorio(reporteUtil, plantillas);
                    //System.out.println(usuarioActual.getNu_dni() + ": reportes PDF generados en directorio servidor aplicaciones");
                    //logger.info(usuarioActual.getNu_dni() + ": reportes PDF generados en directorio servidor aplicaciones");
                    //try {
                    protegerReportes(rutaDirectorioLocal, password);
                    //} catch (Exception e) {
                        //logger.error(usuarioActual.getNu_dni() + ": Sistema: (Error al proteger archivos PDFs) ", e);
                    //}
                    //System.out.println(usuarioActual.getNu_dni() + ": reportes PDF protegido");
                    //logger.info(usuarioActual.getNu_dni() + ": reportes PDF protegido");
                    
                    
                    //inicio generar archivo excel
                    try {
                        PadronElectoral padronElectoral = new PadronElectoral(ubigeo.getCo_departamento(), ubigeo.getCo_provincia(),ubigeo.getCo_distrito(),
                                ubigeo.getCo_mcp(), this.procesoElectoral.getCo_proceso_electoral());
                        padronElectoralService.generarExcelPadronElectoral(padronElectoral, rutaDirectorioLocal, nombreArchivoSinExtension, password);
                    } catch (Exception e) {
                        logger.error(usuarioActual.getNu_dni() + ": Sistema: (Error al generar excel padron electoral) ", e);
                    }
                    //fin generar archivo excel
                    
                    try {

                        ftpUtil.conectar();

                        String directorioRemoto = carpetaRemota + subDirectorio;
                        if (!in_imagenes)
                            directorioRemoto = carpetaRemota + "sin_imagenes/" + subDirectorio;
                        logger.info(usuarioActual.getNu_dni() + ": subir a ftp");
                        ftpUtil.crearDirectorio(directorioRemoto);
                        ftpUtil.eliminarArchivosDeDirectorio(directorioRemoto, ".txt");
                        ftpUtil.subirArchivosDeDirectorio(rutaDirectorioLocal, directorioRemoto);
                    } catch (IOException e) {
                        hayErrorEnUbigeo = true;
                        mensajeErrorEnUbigeo = "Error, no se pudo escribir en FTP.";
                        logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
                    } finally {
                        try {
                            ftpUtil.desconectar();
                        } catch (IOException e) {
                            logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
                        }
                        try {
                            ArchivoUtil.eliminarArchivosDeDirectorio(reporteUtil.getDirectorio());
                            ArchivoUtil.eliminarArchivosDeDirectorio(reporteUtil.getDirectorio()+"tmp/");
                        } catch (IOException e) {
                            logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
                        }
                    }
                } else {
                    hayErrorEnUbigeo = true;
                    mensajeErrorEnUbigeo = "Error, el ubigeo ya se esta procesando en otro lugar.";
                    logger.error(usuarioActual.getNu_dni() + ": No se pudo generar, el ubigeo " + ubigeoProcesando + " ya se esta procesando en otro lugar.");
                }

            } catch (IOException e) {
                hayErrorEnUbigeo = true;
                mensajeErrorEnUbigeo = "Error con archivos o directorios del servidor.";
                logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
            } catch (JRException e) {
                hayErrorEnUbigeo = true;
                mensajeErrorEnUbigeo = "Error al generar PDF.";
                logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
            } catch (Exception e) {
                hayErrorEnUbigeo = true;
                mensajeErrorEnUbigeo = "Ocurrio un error interno.";
                logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
            } finally {
                try {
                    if (generandoUbigeo == 0) {
                        ubigeo.setEs_registro("1");
                        ubigeoPorProcesoService.actualizarEstado(ubigeo);
                    }
                } catch (Exception e) {
                    logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
                }
            }
            
            if (!hayErrorEnUbigeo) {
                try {
                    ArchivoGenerado archivoGenerado = new ArchivoGenerado(ubigeo.getCo_continente(), ubigeo.getCo_pais(), ubigeo.getCo_departamento(), ubigeo.getCo_provincia(), 
                            ubigeo.getCo_distrito(), ubigeo.getCo_mcp(), this.procesoElectoral.getCo_proceso_electoral(), usuarioActual.getNu_dni(), subDirectorio, nombreArchivoPdf, de_justificacion, inImagenes);
                    archivoGenerado.setPass_file(password);
                    registrarLogArchivoGenerado(ubigeo.getCa_formatos_generados(), ubigeo.getIn_imagenes(), archivoGenerado);
                } catch (Exception e) {
                    logger.error(usuarioActual.getNu_dni() + ": Sistema: (Error al intentar conectar con base de datos cuando se registraban logs de seguimiento) ", e);
                }
                resultadoGeneracion.add(Arrays.asList(ubigeo.getCo_departamento(), ubigeo.getCo_provincia(), ubigeo.getCo_distrito(), ubigeo.getCo_mcp(), ubigeo.getNu_prioridad().toString(), "OK"));
                logger.info(usuarioActual.getNu_dni() + ": (si) " + resultadoGeneracion.size());
            } else {
                resultadoGeneracion.add(Arrays.asList(ubigeo.getCo_departamento(), ubigeo.getCo_provincia(), ubigeo.getCo_distrito(), ubigeo.getCo_mcp(), ubigeo.getNu_prioridad().toString(), mensajeErrorEnUbigeo));
                hayErrorEnUbigeos = true;
                contadorUbigeosErroneos++;
                logger.info(usuarioActual.getNu_dni() + ": (no) " + resultadoGeneracion.size() + ". " + mensajeErrorEnUbigeo);
            }
            
            contadorUbigeosProcesados++;
        }
        if (hayErrorEnUbigeos) {
            if(ubigeos.size() > 1){
                respuesta = new RespuestaJSON("info", "No se pudieron generar algunos distritos.");
            }else{
                respuesta = new RespuestaJSON("danger", mensajeErrorEnUbigeo);
            }
        }else{
            this.ubigeos.clear();
        }

        parametroDetalleService.releaseConnection(conn);        

        try {
            usuarioService.actualizarIndicadorProcesando(usuarioActual.getNu_dni(), "0");
        } catch (Exception e) {
            logger.error(usuarioActual.getNu_dni() + ": Sistema: ", e);
        }

        return respuesta;
    }
    
    private void protegerReportes(String ruta, String password){
        List<String> list = ArchivoUtil.obtenerListaRutasPDF(ruta);
        for (int i = 0; i < list.size(); i++) {
            ArchivoUtil.crearArchivoPDFconSeguridad(list.get(i), password);
        }
    }

    public void crearReportesEnDirectorio(ReporteUtil reporteUtil, List<String> plantillas) throws JRException, IOException, DocumentException, Exception {
        prepararDirectorioParaReportes(reporteUtil.getDirectorio());
        crearReporteUnico(reporteUtil, plantillas);
        particionarReportePorTamanio(reporteUtil.getDirectorio(), reporteUtil.getNombreArchivo());
    }

    public void prepararDirectorioParaReportes(String directorio) throws IOException {
        ArchivoUtil.crearDirectorio(directorio);
        ArchivoUtil.eliminarArchivosDeDirectorio(directorio);
    }

    public void crearReporteUnico(ReporteUtil reporteUtil, List<String> plantillas) throws JRException, IOException {
        reporteUtil.configurarVirtualizador();
        reporteUtil.configurarJasperPrint(plantillas);
        reporteUtil.exportarReporte();
    }

    public void particionarReportePorTamanio(String directorio, String nombre) throws IOException, DocumentException, Exception {
        ArchivoUtil.splitPDF(directorio, nombre, parametroDetalleService.obtenerParametroPorDescripcion("04", "TAMANIO_KB").getNu_valor().intValue());
        ArchivoUtil.eliminarArchivo(directorio, nombre);
    }

    public void registrarLogArchivoGenerado(String ca_formatos_generados, String in_imagenes, ArchivoGenerado archivoGenerado) throws Exception {
        if (ca_formatos_generados == null || ca_formatos_generados.equals("0")) {
            archivoGenerado.setCa_formatos_generados("1");
            archivoGeneradoService.registrarArchivoGenerado(archivoGenerado);
        } else {
            archGenHistoricoService.registrarArchGenHistorico(archivoGenerado);
            //if (ca_formatos_generados.equals("1") && !in_imagenes.equalsIgnoreCase(archivoGenerado.getIn_imagenes())) {//verificar validación
                archivoGenerado.setCa_formatos_generados("2");
                archivoGeneradoService.actualizarCaFormatosGenerados(archivoGenerado);
            //}
        }
    }

    private ProcesoElectoral obtenerProcesoActivo() {
        try {
            return procesoElectoralService.consultarProcesoActivo();
        } catch (Exception e) {
            logger.error("Sistema: ", e);
        }
        return null;
    }

    @RequestMapping(value = {"navegarDescargarPadron"}, method = RequestMethod.GET)
    public String navegarDescargarPadron(ModelMap map, HttpServletRequest request) {
        return "descargarPadron";
    }

    @RequestMapping(value = "/verificarDescargaArchivo", method = RequestMethod.GET)
    public @ResponseBody
    RespuestaJSON verificarDescargaArchivo(@RequestParam(value = "co_departamento") String co_departamento,
            @RequestParam(value = "co_provincia") String co_provincia,
            @RequestParam(value = "co_distrito") String co_distrito,
            @RequestParam(value = "co_mcp[]") String[] co_mcp,
            @RequestParam(value = "in_imagenes", required = false) boolean in_imagenes) {
        String inexistentes = "";
        String existentes = "";
        String ti_respuesta = "success";
        String de_mensaje = "Todo OK";
        this.procesoElectoral = obtenerProcesoActivo();
        String inImagenes = (in_imagenes) ? "1" : "0";
        try {
            if (co_mcp.length > 1) {
                for (String mcp : co_mcp) {
                    if (archivoGeneradoService.consultarArchivoGeneradoIndicandoImagenes(new ArchivoGenerado(co_departamento, co_provincia, co_distrito, mcp, this.procesoElectoral.getCo_proceso_electoral(), inImagenes)) == null) {
                        inexistentes = inexistentes + mcp + ",";
                    } else {
                        existentes = existentes + mcp + ",";
                    }
                }
                if (!inexistentes.equals("")) {
                    inexistentes = inexistentes.substring(0, inexistentes.length() - 1);
                    existentes = existentes.equals("") ? existentes : existentes.substring(0, existentes.length() - 1);
                    ti_respuesta = "info";
                }
            } else {
                if (archivoGeneradoService.consultarArchivoGeneradoIndicandoImagenes(new ArchivoGenerado(co_departamento, co_provincia, co_distrito,  co_mcp[0], this.procesoElectoral.getCo_proceso_electoral(), inImagenes)) == null) {
                    de_mensaje = "Este reporte no ha sido generado";
                    ti_respuesta = "info";
                }
            }
        } catch (Exception e) {
            ti_respuesta = "danger";
            de_mensaje = "Error al intentar conectar con base de datos";
            logger.error("Sistema: ", e);
        }
        RespuestaJSON respuesta = new RespuestaJSON(ti_respuesta, de_mensaje, inexistentes.equalsIgnoreCase("") ? "" : inexistentes + "-" + existentes);
        return respuesta;
    }

    @RequestMapping("/accionDescargarPadron")
    public void accionDescargarPadron(@RequestParam(value = "co_departamento") String co_departamento,
            @RequestParam(value = "co_provincia") String co_provincia,
            @RequestParam(value = "co_distrito") String co_distrito,
            @RequestParam(value = "co_mcp") String[] co_mcp,
            @RequestParam(value = "in_imagenes", required = false) boolean in_imagenes,
            HttpServletRequest request, HttpServletResponse response) {

        in_imagenes = true;
        String ti_respuesta = "";
        String carpetaRemota = "/padron/";
        String nombreArchivoSinExtension;
        this.procesoElectoral = obtenerProcesoActivo();

        //FTPUtil ftpUtil = null;
        FTPSUTIL ftpUtil = null;

        try {
            //ftpUtil = new FTPUtil(parametroDetalleService.obtenerParametroPorDescripcion("07", "URL").getDe_valor(), 21,
            ftpUtil = new FTPSUTIL(parametroDetalleService.obtenerParametroPorDescripcion("06", "URL").getDe_valor(), 21,
                    parametroDetalleService.obtenerParametroPorDescripcion("07", "USUARIO").getDe_valor(),
                    parametroDetalleService.obtenerParametroPorDescripcion("07", "CLAVE").getDe_valor());
            ftpUtil.conectar();

        } catch (Exception e) {
            ti_respuesta = "danger";
            logger.error("Sistema: ", e);
            return;
        }

        if (co_mcp.length > 1) {
            nombreArchivoSinExtension = "PE-CP" + co_departamento + co_provincia + co_distrito;
        } else {
            nombreArchivoSinExtension = "PE-CP" + co_departamento + co_provincia + co_distrito + co_mcp[0];
        }
        response.setHeader("Content-Disposition", "attachment; filename=" + nombreArchivoSinExtension + ConstantesUtil.EXTENSION_ZIP);
        response.setContentType("application/zip");

        String subDirectorio = co_departamento + "/" + co_provincia + "/" + co_distrito + "/";
        if (!in_imagenes) {
            subDirectorio = "sin_imagenes/" + subDirectorio;
        }

        try {
            ZipOutputStream zos = new ZipOutputStream(response.getOutputStream());
            ftpUtil.descargarArchivosDeVariosDirectorios(carpetaRemota + subDirectorio, co_mcp, zos);
        } catch (IOException e) {
            ti_respuesta = "danger";
            logger.error("Sistema: ", e);
        } catch (Exception e) {
            ti_respuesta = "danger";
            logger.error("Sistema: ", e);
        } finally {
            try {
                ftpUtil.desconectar();
            } catch (IOException e) {
                logger.error("Sistema: ", e);
            }
        }
    }

    @RequestMapping(value = "/cargarUbigeos", method = RequestMethod.POST)
    public @ResponseBody
    RespuestaJSON cargarUbigeos(@ModelAttribute("archivo") MultipartFile archivo, HttpServletRequest request) {

        String ti_respuesta = "danger";
        //TEMPORAL: fallo con dll
        String de_mensaje = "Error al cargar el archivo.";
        RespuestaJSON respuestaJson = new RespuestaJSON(ti_respuesta, de_mensaje);

        this.procesoElectoral = obtenerProcesoActivo();

        try {
            File file = ArchivoUtil.convertirMultipartFileAArchivo(archivo);
            FileInputStream fileInput = new FileInputStream(file);
            respuestaJson = cargarExcel(file, fileInput, this.procesoElectoral.getCo_proceso_electoral(), usuarioActual.getNu_dni());
        } catch (IOException e) {
            logger.error("Sistema: ", e);
        } catch (Exception e) {
            logger.error("Sistema: ", e);
        }

        return respuestaJson;
    }

    public RespuestaJSON cargarExcel(File archivo, FileInputStream file, String co_proc_verifica, String usuario) throws IOException, InvalidFormatException {
        String ti_respuesta = "success";
        String mensaje = "Se cargaron los ubigeos mínimos con éxito.";
        String mensajeError = "";
        Workbook workbook;
        Row row;
        Cell cell;

        try {

            if (archivo.getName().endsWith(".xls") || archivo.getName().endsWith(".xlsx")) {
                workbook = WorkbookFactory.create(file);
            } else {
                ti_respuesta = "danger";
                mensaje = "La extensión del archivo no corresponde a un formato Excel.";
                return new RespuestaJSON(ti_respuesta, mensaje);
            }

            Sheet sheet = workbook.getSheetAt(0);
            Iterator rowIter = sheet.rowIterator();

            try {
                ubigeoPorProcesoService.eliminarUbigeos(co_proc_verifica, usuario);

            } catch (Exception e) {
                ti_respuesta = "danger";
                mensaje = "Error al intentar cargar información.";
                return new RespuestaJSON(ti_respuesta, mensaje);
            }

            UbigeoPorProceso ubigeoPorProceso = new UbigeoPorProceso();
            ubigeoPorProceso.setCo_continente("92");
            ubigeoPorProceso.setCo_pais("33");
            ubigeoPorProceso.setEs_registro("1");
            ubigeoPorProceso.setCo_proceso_electoral(co_proc_verifica);
            ubigeoPorProceso.setUs_crea_audi(usuario);

            while (rowIter.hasNext()) {
                row = (Row) rowIter.next();

                cell = row.getCell(0);
                if (cell != null) {
                    if (ArchivoUtil.validarCeldaNumero(cell, 99)) {
                        ubigeoPorProceso.setCo_departamento(Util.agregarFormatoAdelante("00", Integer.toString((int) cell.getNumericCellValue())));
                    } else if (ArchivoUtil.validarCeldaTexto(cell, 2)) {
                        ubigeoPorProceso.setCo_departamento(cell.getStringCellValue());
                    } else {
                        ti_respuesta = "danger";
                        mensaje = "Error en el formato del archivo. Revisar la columna A de la fila: " + (row.getRowNum() + 1);
                        break;
                    }

                } else {
                    ti_respuesta = "danger";
                    mensaje = "Error en el formato del archivo. Revisar la columna A de la fila: " + (row.getRowNum() + 1);
                    break;
                }

                cell = row.getCell(1);
                if (cell != null) {
                    if (ArchivoUtil.validarCeldaNumero(cell, 99)) {
                        ubigeoPorProceso.setCo_provincia(Util.agregarFormatoAdelante("00", Integer.toString((int) cell.getNumericCellValue())));
                    } else if (ArchivoUtil.validarCeldaTexto(cell, 2)) {
                        ubigeoPorProceso.setCo_provincia(cell.getStringCellValue());
                    } else {
                        ti_respuesta = "danger";
                        mensaje = "Error en el formato del archivo. Revisar la columna B de la fila: " + (row.getRowNum() + 1);
                        break;
                    }
                } else {
                    ti_respuesta = "danger";
                    mensaje = "Error en el formato del archivo. Revisar la columna B de la fila: " + (row.getRowNum() + 1);
                    break;
                }

                cell = row.getCell(2);
                if (cell != null) {
                    if (ArchivoUtil.validarCeldaNumero(cell, 99)) {
                        ubigeoPorProceso.setCo_distrito(Util.agregarFormatoAdelante("00", Integer.toString((int) cell.getNumericCellValue())));
                    } else if (ArchivoUtil.validarCeldaTexto(cell, 2)) {
                        ubigeoPorProceso.setCo_distrito(cell.getStringCellValue());
                    } else {
                        ti_respuesta = "danger";
                        mensaje = "Error en el formato del archivo. Revisar la columna C de la fila: " + (row.getRowNum() + 1);
                        break;
                    }
                } else {
                    ti_respuesta = "danger";
                    mensaje = "Error en el formato del archivo. Revisar la columna C de la fila: " + (row.getRowNum() + 1);
                    break;
                }
                
                cell = row.getCell(3);
                if (cell != null) {
                    if (ArchivoUtil.validarCeldaNumero(cell, 99)) {
                        ubigeoPorProceso.setCo_mcp(Util.agregarFormatoAdelante("000", Integer.toString((int) cell.getNumericCellValue())));
                    } else if (ArchivoUtil.validarCeldaTexto(cell, 3)) {
                        ubigeoPorProceso.setCo_mcp(cell.getStringCellValue());
                    } else {
                        ti_respuesta = "danger";
                        mensaje = "Error en el formato del archivo. Revisar la columna D de la fila: " + (row.getRowNum() + 1);
                        break;
                    }
                } else {
                    ti_respuesta = "danger";
                    mensaje = "Error en el formato del archivo. Revisar la columna D de la fila: " + (row.getRowNum() + 1);
                    break;
                }

                cell = row.getCell(4);
                if (cell != null && ArchivoUtil.validarCeldaNumero(cell, 999999999)) {
                    ubigeoPorProceso.setNu_prioridad((int) cell.getNumericCellValue());
                } else {
                    ti_respuesta = "danger";
                    mensaje = "Error en el formato del archivo. Revisar la columna E de la fila: " + (row.getRowNum() + 1);
                    break;
                }

                try {
                    if(ubigeoPorProcesoService.obtenerCantidadRegistrosCoincidentesConUbigeo(ubigeoPorProceso)>0){
                        ubigeoPorProcesoService.registrarUbigeoPorProceso(ubigeoPorProceso);
                    }else{
                        mensajeError = mensajeError + (row.getRowNum() + 1) + ", ";
                    }                    

                } catch (Exception e) {
                    try {
                        ubigeoPorProcesoService.eliminarUbigeos(co_proc_verifica, usuario);
                    } catch (Exception ex) {
                        logger.error("Error: ", ex);
                    }
                    ti_respuesta = "danger";
                    mensaje = "Error al Actualizar la información. (Fila: " + (row.getRowNum() + 1 + ")");
                    logger.error("Sistema: ", e);
                    break;
                }
            }
            
            if(!mensajeError.equalsIgnoreCase("")){
                ti_respuesta = "danger";
                mensaje = "Error en el archivo. No se encontró en la BD el ubigeo de la(s) fila(s):"+mensajeError.substring(0, mensajeError.length() - 2) + ".";
            }

        } catch (IOException e) {
            logger.error("Sistema: ", e);
            ti_respuesta = "danger";
            mensaje = "Error al intentar leer el archivo.";
        }

        return new RespuestaJSON(ti_respuesta, mensaje);
    }

    @RequestMapping(value = "/mostrarResultadoUbigeo", method = RequestMethod.GET)
    public String mostrarResultadoUbigeo(ModelMap map, HttpServletRequest request) {

        boolean in_generados_antes = false;

        this.procesoElectoral = obtenerProcesoActivo();
        try {
            this.ubigeos = ubigeoPorProcesoService.listarUbigeosPorProcesoYUsuario(this.procesoElectoral.getCo_proceso_electoral(), usuarioActual.getNu_dni());
        } catch (Exception e) {
            this.ubigeos = new ArrayList<UbigeoPorProceso>();
            logger.error("Sistema: ", e);
        }        
        
        for (UbigeoPorProceso ubigeo : this.ubigeos) {
            ArchivoGenerado archivoGenerado = archivoGeneradoService.consultarArchivoGenerado(new ArchivoGenerado(ubigeo.getCo_departamento(), ubigeo.getCo_provincia(), ubigeo.getCo_distrito(), ubigeo.getCo_mcp(), this.procesoElectoral.getCo_proceso_electoral()));
            if (archivoGenerado != null) {
                ubigeo.setCa_formatos_generados(archivoGenerado.getCa_formatos_generados());
                ubigeo.setIn_imagenes(archivoGenerado.getIn_imagenes());
                in_generados_antes = true;
            } else {
                ubigeo.setCa_formatos_generados("0");
            }
        }
        map.addAttribute("ubigeos", this.ubigeos);
        map.addAttribute("in_generados_antes", in_generados_antes);

        return "resultadoUbigeos";
    }

    @RequestMapping(value = "/mostrarResultadoGeneracion", method = RequestMethod.GET)
    public String mostrarResultadoGeneracion(ModelMap map, HttpServletRequest request) {
        map.addAttribute("resultadoGeneracion", resultadoGeneracion);
        map.addAttribute("hayErrorEnUbigeos", hayErrorEnUbigeos);
        return "resultadoGeneracion";
    }

    @RequestMapping(value = "/descargarResultadoGeneracion", method = RequestMethod.GET)
    public void descargarResultadoGeneracion(HttpServletRequest request, HttpServletResponse response) {

        String carpetaLocal = RUTA_PADRON;
        this.procesoElectoral = obtenerProcesoActivo();
        String nombreArchivoSinExtension = "Resultado" + this.procesoElectoral.getCo_proceso_electoral();

        try {
            List<List<String>> tabla = new ArrayList<List<String>>();
            for (List<String> u : resultadoGeneracion) {
                if (!u.get(4).equalsIgnoreCase("OK")) {
                    tabla.add(u);
                }
            }

            //ArchivoUtil.crearArchivoExcel(tabla, carpetaLocal, nombreArchivoSinExtension + EXTENSION_EXCEL);
            ArchivoUtil.escribirExcelEnResponse(carpetaLocal, nombreArchivoSinExtension, response);

        } catch (IOException e) {
            logger.error("Sistema: ", e);
        } catch (Exception e) {
            logger.error("Sistema: ", e);
        }

    }

    @RequestMapping(value = "/mantenerSesion", method = RequestMethod.GET)
    private @ResponseBody String mantenerSesion() {
        return "UBIGEO: " + ubigeoProcesando + " <br> AVANCE: " + contadorUbigeosProcesados + "/" + this.ubigeos.size() + " UBIGEOS" + ((hayErrorEnUbigeos)?" (Con " + contadorUbigeosErroneos + " erroneos)":"");
    }
    
    @RequestMapping(value = "/obtenerClaveArchivoGenerado", method = RequestMethod.POST)
    public @ResponseBody
    Map<String, String> obtenerClaveArchivoGenerado(@RequestParam String codCont, @RequestParam String codPais, 
            @RequestParam String codDep, @RequestParam String codPro, @RequestParam String codDis,  @RequestParam String codMcp) {
        Map<String, String> respuesta = new HashMap<String, String>();
        try {
            String clave = archivoGeneradoService.obtenerClaveArchivoGenerado(this.procesoElectoral.getCo_proceso_electoral(), codCont, codPais, codDep, codPro, codDis, codMcp);
            respuesta.put("clave", clave);
        } catch (Exception e) {
            logger.error("Error al conectar con base de datos, obtenerDepartamentos.", e);
        }
        return respuesta;
    }
}
