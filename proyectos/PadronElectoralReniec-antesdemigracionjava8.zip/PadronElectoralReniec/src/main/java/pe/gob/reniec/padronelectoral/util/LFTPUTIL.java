/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.zip.ZipOutputStream;
/**
 *
 * @author externo.ecueva
 */
public class LFTPUTIL {
    // Usamos el logger con el nombre de la nueva clase
    private static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(LFTPUTIL.class);
    
    private String server;
    private int port;
    private String user;
    private String pass;
    
    // El cliente FTP ya no se instancia ni se usa.
    // private FTPSClient ftpClient;
    
    public LFTPUTIL(String server, int port, String user, String pass) {
        this.server = server;
        this.port = port;
        this.user = user;
        this.pass = pass;
    }
    
    /**
     * OBSOLETO: Con lftp -c, cada comando se conecta y desconecta.
     */
    public void conectar() throws IOException {
       logger.info("El método conectar ya no es necesario con el enfoque lftp.");
    }
    
    /**
     * OBSOLETO: Con lftp -c, cada comando se conecta y desconecta.
     */
    public void desconectar() throws IOException {
        logger.info("El método desconectar ya no es necesario con el enfoque lftp.");
    }

    // Helper method para construir el comando base de lftp
    private String buildLftpBaseCommand() {
        // Usamos -c para ejecutar comandos y configuramos ssl:verify-certificate no 
        // para replicar el comportamiento inicial del usuario
        return String.format(
            "set ssl:verify-certificate no; open ftp://%s:%s@%s:%d; ",
            this.user, this.pass, this.server, this.port
        );
    }
    
    // Helper method para ejecutar el comando en el sistema
    /*private void executeLftpCommand(String commandSuffix) throws IOException, InterruptedException {
        String fullCommand = buildLftpBaseCommand() + commandSuffix;
        
        // Ejecutamos lftp -c "full_command_string"
        // Este es el punto clave que permite usar TLS 1.2
        ProcessBuilder processBuilder = new ProcessBuilder("lftp", "-c", fullCommand);
        processBuilder.redirectErrorStream(true); 

        Process process = processBuilder.start();
        
        // Leer la salida del proceso para evitar bloqueos del buffer
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                logger.info("LFTP Output: " + line);
            }
        }
        
        int exitCode = process.waitFor();
        if (exitCode != 0) {
            // Capturamos cualquier error reportado por lftp
            throw new IOException("El comando LFTP falló con código de salida: " + exitCode);
        }
    }*/
    
    // Helper method para ejecutar el comando en el sistema (Java 6 Compatible)
    private void executeLftpCommand(String commandSuffix) throws IOException, InterruptedException {
        String fullCommand = buildLftpBaseCommand() + commandSuffix;
        
        ProcessBuilder processBuilder = new ProcessBuilder("lftp", "-c", fullCommand);
        processBuilder.redirectErrorStream(true); 

        Process process = processBuilder.start();
        
        // --- INICIO: Manejo de Streams compatible con Java 6 (sin try-with-resources) ---
        BufferedReader reader = null;
        InputStream is = null;

        try {
            is = process.getInputStream();
            reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = reader.readLine()) != null) {
                logger.info("LFTP Output: " + line);
            }
        } finally {
            // Asegurarse de cerrar los recursos en el orden correcto en el finally
            if (reader != null) {
                try { reader.close(); } catch (IOException e) { logger.error("Error cerrando reader", e); }
            }
            if (is != null) {
                 try { is.close(); } catch (IOException e) { logger.error("Error cerrando InputStream", e); }
            }
        }
        // --- FIN: Manejo de Streams compatible con Java 6 ---
        
        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IOException("El comando LFTP falló con código de salida: " + exitCode);
        }
    }


    public void subirArchivo(String local, String remoto) throws IOException {
        try {
            // El comando lftp 'put' sube el archivo local al remoto
            executeLftpCommand(String.format("put %s -o %s", local, remoto));
            logger.info("Archivo subido: " + local + " a " + remoto);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Restaurar el flag de interrupción
            throw new IOException("Subida interrumpida", e);
        }
    }

    public void subirArchivosDeDirectorio(String local, String remoto) throws IOException {

        File directorio = new File(local);
        File[] archivosEnDirectorio = directorio.listFiles();

        if (archivosEnDirectorio != null && archivosEnDirectorio.length > 0) {
            for (File item : archivosEnDirectorio) {
                // Asegúrate de que las rutas remotas usen el separador correcto (siempre "/")
                String remoteFilePath = remoto + "/" + item.getName();

                if (item.isFile()) {
                    String localFilePath = item.getAbsolutePath();
                    subirArchivo(localFilePath, remoteFilePath);
                }
            }
        }
    }

    public void eliminarArchivosDeDirectorio(String directorioRemoto) throws IOException {
        try {
            // Usamos 'rm' para eliminar archivos específicos dentro del directorio remoto
            // Este enfoque es más limitado que el original en Java, solo borra archivos si se sabe el nombre.
            // Para replicar la lógica original que listaba y borraba:
            // Necesitarías ejecutar un comando lftp 'ls' y parsear la salida en Java, lo cual es complejo.
            // Como alternativa simple, usamos 'nuke' que borra todo el contenido (con precaución):
            executeLftpCommand(String.format("cd %s; nuke *", directorioRemoto));
            logger.info("Archivos en directorio remoto eliminados: " + directorioRemoto);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Eliminación interrumpida", e);
        }
    }

    public void crearDirectorio(String directorio) throws IOException {
         try {
            // lftp mkdir crea directorios recursivamente si es necesario (-p)
            executeLftpCommand(String.format("mkdir -p %s", directorio));
            logger.info("Directorio creado: " + directorio);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Creación de directorio interrumpida", e);
        }
    }
    
    /* 
     * NOTA IMPORTANTE: Los métodos de descarga que utilizan ZipOutputStream y Streams internos de Java 
     * son incompatibles con el enfoque lftp -c. Requieren una refactorización mayor (descarga 
     * a temporal local, luego lectura en Java) o actualizar a Java 8.
     * Estos métodos se dejan sin modificar.
    */

    public void descargarArchivo(String remoto, OutputStream os) throws IOException { 
         throw new UnsupportedOperationException("Este método requiere refactorización para usar archivos temporales locales.");
    }
    public void descargarArchivosDeVariosDirectorios(String remoto, String[] directorios, ZipOutputStream zos) throws IOException { 
         throw new UnsupportedOperationException("Este método requiere refactorización para usar archivos temporales locales.");
    }
    public void descargarArchivosDeUnDirectorio(String remoto, String directorio, ZipOutputStream zos) throws IOException { 
         throw new UnsupportedOperationException("Este método requiere refactorización para usar archivos temporales locales.");
    }


    // Getters and Setters (sin cambios) ...
    public String getServer() { return server; }
    public void setServer(String server) { this.server = server; }
    public int getPort() { return port; }
    public void setPort(int port) { this.port = port; }
    public String getUser() { return user; }
    public void setUser(String user) { this.user = user; }
    public String getPass() { return pass; }
    public void setPass(String pass) { this.pass = pass; }
}
