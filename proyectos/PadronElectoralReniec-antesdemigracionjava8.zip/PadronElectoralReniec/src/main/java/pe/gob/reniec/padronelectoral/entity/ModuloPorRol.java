/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hcruz
 */
@XmlRootElement
public class ModuloPorRol extends Auditoria implements Serializable {

    private String co_modulo;
    private String co_rol;

    public ModuloPorRol(String co_modulo, String co_rol, String co_usuario) {
        this.co_modulo = co_modulo;
        this.co_rol = co_rol;
        this.es_registro = "1";
        this.us_crea_audi = co_usuario;
        this.us_modi_audi = co_usuario;
    }

    public ModuloPorRol(String co_rol) {
        this.co_rol = co_rol;
    }

    public String getCo_modulo() {
        return co_modulo;
    }

    public void setCo_modulo(String co_modulo) {
        this.co_modulo = co_modulo;
    }

    public String getCo_rol() {
        return co_rol;
    }

    public void setCo_rol(String co_rol) {
        this.co_rol = co_rol;
    }

}
