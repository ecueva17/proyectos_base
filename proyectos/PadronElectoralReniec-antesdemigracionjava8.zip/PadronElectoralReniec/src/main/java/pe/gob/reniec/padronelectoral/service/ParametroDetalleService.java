/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.service;

import java.sql.Connection;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import pe.gob.reniec.padronelectoral.dao.ParametroDetalleDao;
import pe.gob.reniec.padronelectoral.entity.ParametroDetalle;

/**
 *
 * @author eibanez
 */
@Service
public class ParametroDetalleService {

    @Autowired
    ParametroDetalleDao parametroDetalleDao;

    @Autowired
    private DataSource dataSource;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Connection getConnection() {
        return DataSourceUtils.getConnection(dataSource);
    }
    
    public void releaseConnection(Connection connection){
        DataSourceUtils.releaseConnection(connection, dataSource); 
    }

    public void setParametroDetalleDao(ParametroDetalleDao parametroDetalleDao) {
        this.parametroDetalleDao = parametroDetalleDao;
    }

    public ParametroDetalle obtenerParametroPorDescripcion(String co_parametro, String de_parametro) throws Exception {

        ParametroDetalle result = null;

        try {
            result = parametroDetalleDao.obtenerParametroPorDescripcion(co_parametro, de_parametro);
        } catch (Exception e) {
            throw new Exception(e);
        }
        return result;

    }

}
