<%-- 
    Document   : inicio
    Created on : 10/03/2014, 12:18:23 PM
    Author     : ydelatorre
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib prefix="sec" uri="http://www.springframework.org/security/tags" %>

<input type="hidden" value="${in_generados_antes}" id="in_generados_antes">

<div class="cajatexto"><b>Resultados de carga:</b></div>
<div class="cajascroll">
    <table>
        <tr>
            <td class="itemlista">Departamento</td>
            <td class="itemlista">Provincia</td>
            <td class="itemlista">Distrito</td>
            <td class="itemlista">Muni. Centro Poblado</td>
            <td class="itemlista">Prioridad</td>
            <td class="itemlista">Generado Antes</td>
        </tr>
        <c:forEach items="${ubigeos}" var="u">
        <tr>
            <td class="itemlista">${u.co_departamento}</td>
            <td class="itemlista">${u.co_provincia}</td>
            <td class="itemlista">${u.co_distrito}</td>
            <td class="itemlista">${u.co_mcp}</td>
            <td class="itemlista">${u.nu_prioridad}</td>
            <td class="itemlista">
                <c:if test="${u.ca_formatos_generados != 0}"><span style="color:red;">Si</span></c:if>
                <c:if test="${u.ca_formatos_generados == 0}"><span style="color:green;">No</span></c:if>
            </td>
        </tr>
        </c:forEach>
    </table>
</div>