<%-- 
    Document   : cambiarClave
    Created on : 03/03/2015, 04:04:11 PM
    Author     : zmontes
--%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
    <body>
        <script src="<c:url value="/resources/js/index.js"/>"></script>
        <script src="<c:url value="/resources/js/utiles.js"/>"></script>
        <div id="panel-busqueda" class="panel panel-primary">

            <div class="panel-heading">Cambiar Clave</div>
            <div class="panel-body">
                <form name="frmCambiarClave" id="frmCambiarClave">
                    <div class="row">
                        <label class="col-lg-3 col-md-3 col-sm-6 col-xs-12">Clave:</label>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <input type="password" maxlength="8" id = "clave" name="clave" onchange="verificarClaveActual(this.value);" tabindex="1"
                                   autocomplete="off"/>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-lg-3 col-md-3 col-sm-6 col-xs-12">Nueva Clave:</label>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <input type="password" maxlength="15" id = "nuevaClave1" name="nuevaClave1" tabindex="2" onchange="verificarNuevaClave(this.value);" disabled="disabled"
                                   autocomplete="off"/>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-lg-3 col-md-3 col-sm-6 col-xs-12">Repita Nueva Clave:</label>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <input type="password" maxlength="15" id = "nuevaClave2" name="nuevaClave2" tabindex="2"  onchange="verificarClave(this.value);" disabled="disabled"
                                   autocomplete="off"/>
                        </div>
                    </div>
                    <div class="pieLogin" style="text-align: right;" >
                        <input id="btnAcceder" type="button" value="Guardar" class="btn btn-primary" onclick="cambiarClave();" disabled="disabled"/>
                    </div>
                    <div class="alert hide" id="mensaje" role="alert"></div>
                </form>
            </div>
        </div>
    </body>
</html>
