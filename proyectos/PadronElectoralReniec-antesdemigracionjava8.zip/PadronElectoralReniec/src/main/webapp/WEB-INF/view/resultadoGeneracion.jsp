<%-- 
    Document   : inicio
    Created on : 10/03/2014, 12:18:23 PM
    Author     : ydelatorre
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib prefix="sec" uri="http://www.springframework.org/security/tags" %>

<div class="cajatexto"><b>Resultados de Generacion:</b>
    
        <c:if test="${hayErrorEnUbigeos}"><a href="#" id="btnDescarga" class="enlacelista" >Descargar Err&oacute;neos</a></c:if>
        <c:if test="${!hayErrorEnUbigeos}"><a href="#" id="btnDescargaDisabled" class="enlacelista" >Descargar Err&oacute;neos</a></c:if>
   

</div>
<div class="cajascroll">
    <table>
        <tr>
            <td class="itemlista">Departamento</td>
            <td class="itemlista">Provincia</td>
            <td class="itemlista">Distrito</td>
            <td class="itemlista">Muni. Centro Poblado</td>
            <td class="itemlista">Prioridad</td>
            <td class="itemlista">OK</td>
        </tr>
        <c:forEach items="${resultadoGeneracion}" var="g">
            <tr>
                <td class="itemlista">${g[0]}</td>
                <td class="itemlista">${g[1]}</td>
                <td class="itemlista">${g[2]}</td>
                <td class="itemlista">${g[3]}</td>
                <td class="itemlista">${g[4]}</td>
                <td class="itemlista">
                    <c:if test="${g[5] == 'OK'}"><span class="glyphicon glyphicon-ok" style="color:green;"></span> </c:if>
                    <c:if test="${g[5] != 'OK'}"><span class="glyphicon glyphicon-remove"style="color:red"></span> </c:if>
                    </td>
                </tr>
        </c:forEach>
    </table>
</div>
<script>
    $(document).ready(function() {
        $("#btnDescarga").click(function(event) {
            event.preventDefault();
            window.location = ctx + "/descargarResultadoGeneracion";
        });
    });
</script>
