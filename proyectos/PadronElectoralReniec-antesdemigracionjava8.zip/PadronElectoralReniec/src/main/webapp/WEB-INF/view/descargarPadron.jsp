<%-- 
    Document   : generarPadron
    Created on : 03/03/2015, 04:05:50 PM
    Author     : zmontes
--%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
    <body>
        <c:set var="ctx" value="${pageContext.request.contextPath}" scope="request" />
        <div id="panel-busqueda" class="panel panel-primary">

            <div class="panel-heading">Descargar Padr�n Electoral MCP</div>
            <div class="panel-body">

                <form id="formDescargarReporte" name="formDescargarReporte" method="GET" action="${ctx}/accionDescargarPadron">
                    <div  class="row">
                        <div class="col-xs-12 col-md-6 col-lg-4">
                            <label class="filtro">Departamento</label>
                            <select id="co_departamento" name="co_departamento" class="form-control input-sm" onChange="cargarProvincias(this.value);">
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-6 col-lg-4">
                            <label class="filtro">Provincia</label>
                            <select id="co_provincia" name="co_provincia" class="form-control input-sm" onChange="cargarDistritos(this.value);">
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-6 col-lg-4">
                            <label class="filtro">Distrito</label>
                            <select id="co_distrito" name="co_distrito" class="form-control input-sm" onChange="cargarMCP(this.value);">
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-6 col-lg-4">
                            <label class="filtro">MCP</label>
                            <select class="form-control input-sm" id="co_mcp" name="co_mcp" multiple="multiple" onchange="habilitarBoton()">
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-6 col-lg-4 checkbox" style="display: none;">
                            <label>
                                <input id="in_imagenes" name="in_imagenes" type="checkbox"> Con Im�genes
                            </label>
                        </div>
                        <div class="col-xs-12 col-md-12 col-lg-12" style="text-align: right; padding-top: 10px;" >
                            <input id="btnDescargarReporte" type="button" value="Descargar reporte" class="btn btn-primary" onclick="verificarDescargaArchivo();" disabled="disabled"/>
                        </div>
                        <div id="btnMostrarClaveArchivo" class="col-xs-12 col-md-12 col-lg-12" style="text-align: right; padding-top: 10px; display: none;" >
                            <input id="btnDescargarReporte" type="button" value="Obtener Clave" class="btn btn-primary" onclick="obtenerClaveArchivo();"/>
                        </div>
                        <div id="divMostrarClaveArchivo" class="col-xs-12 col-md-12 col-lg-12" style="text-align: right; padding-top: 10px; display: none;">
                            <label class="filtro">Clave de archivo: </label>
                            <span id="miclavearchivodescargado"></span>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <script src="<c:url value="/resources/js/index.js"/>"></script>
        <script>
            $(document).ready(function () {
                inicializarDescargarPadron();
            });
        </script>
    </body>
</html>
