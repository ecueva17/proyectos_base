<%-- 
    Document   : generarPadron
    Created on : 03/03/2015, 04:05:50 PM
    Author     : zmontes
--%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
    <head>
        <script src="<c:url value="/resources/js/jquery.form.min.js" />"></script>
    </head>
    <body>
        <c:set var="ctx" value="${pageContext.request.contextPath}" scope="request" />
        <div id="panel-busqueda" class="panel panel-primary">

            <div class="panel-heading">Generar Padr�n Electoral MCP</div>
            <div class="panel-body">
                <form id="cargaform" name="cargaform" method="post" action="${pageContext.request.contextPath}/cargarUbigeos">
                    <label for="archivo">Cargar Archivo de Ubigeos (EXCEL):</label>
                    <input type="file" name="archivo" id="archivo" onchange="javascript:limpiarGeneracion();" />
                    <div style="text-align: right; padding-top: 10px;">
                        <input type="submit" name="btnCargar" id="btnCargar" value="Cargar archivo" class="btn btn-primary"/>
                    </div>
                </form>                    
                <div id="tablaResultadoUbigeos"></div><br/><hr>

                <form id="formGenerarReporte" name="formGenerarReporte" >
                    <label>Generar Padron de Ubigeos Cargados:</label>
                    <div id="caja_justificacion">
                        <p>Existe uno o mas ubigeos que han sido generados anteriormente. Ingrese la justificaci&oacute;n:</p>
                        <div style="margin: 0 25px;">
                            <textarea maxlength="250" name="message" cols="50" rows="6" required id="de_justificacion" onpaste="return false;" ></textarea>
                            <br>
                            <span id="validacionJustificacion" style="color: red;"></span>
                        </div>                        
                    </div>
                    <br/>
                    <div style="margin: 0 20px; display: none;">
                        <input id="in_imagenes" name="in_imagenes" type="checkbox"> Con Im�genes
                    </div>
                    <div style="text-align: right; padding-top: 10px;" >
                        <input id="btnGenerarReporte" type="button" value="Generar reporte" class="btn btn-primary" onclick="generarPadron();" disabled="disabled"/>
                    </div>
                </form>
                <div id="tablaResultadoGeneracion"></div>
            </div>

        </div>
                    
        <script src="<c:url value="/resources/js/index.js"/>"></script>
        <script>
            $(document).ready(function() {
                inicializarGenerarPadron();
            });
        </script>
    </body>
</html>
