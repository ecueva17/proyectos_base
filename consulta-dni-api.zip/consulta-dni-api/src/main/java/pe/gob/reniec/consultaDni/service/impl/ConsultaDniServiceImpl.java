package pe.gob.reniec.consultaDni.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.gob.reniec.consultaDni.dao.ConsultaDniDao;
import pe.gob.reniec.consultaDni.model.Ciudadano;
import pe.gob.reniec.consultaDni.service.ConsultaDniService;

@Service
public class ConsultaDniServiceImpl implements ConsultaDniService {

    @Autowired
    private ConsultaDniDao consultaDniDao;

    @Override
    public Ciudadano getCiudadano(String dni) {
        return consultaDniDao.getCiudadano(dni);
    }
}
