package pe.gob.reniec.consultaDni.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.consultaDni.dao.ConsultaDniDao;
import pe.gob.reniec.consultaDni.model.Ciudadano;

@Repository
public class ConsultaDniDaoImpl implements ConsultaDniDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public Ciudadano getCiudadano(String dni) {
        try{
            String query = "select  a.NU_DNI, a.PRENOM_INSCRITO, a.AP_PRIMER, a.AP_SEGUNDO, a.AP_CASADA, a.NO_DOMICILIO , a.CO_DEPARTAMENTO_DOMICILIO, a.CO_PROVINCIA_DOMICILIO,\n" +
                    " a.CO_DISTRITO_DOMICILIO, a.NO_DEPARTAMENTO_DOMICILIO, a.NO_PROVINCIA_DOMICILIO, a.NO_DISTRITO_DOMICILIO\n" +
                    " from idtrmweb.gevw_ani a\n" +
                    //" where nu_dni = '"+dni+"'";
                    " where nu_dni = ?";

            return this.jdbcTemplate.queryForObject(query, new Object[]{dni}, (rs, rowNum) -> {
                Ciudadano ciudadano = new Ciudadano();
                ciudadano.setDni(rs.getString("NU_DNI"));
                ciudadano.setNombre(rs.getString("PRENOM_INSCRITO"));
                ciudadano.setApPaterno(rs.getString("AP_PRIMER"));
                ciudadano.setApMaterno(rs.getString("AP_SEGUNDO"));
                ciudadano.setApCasada(rs.getString("AP_CASADA"));
                ciudadano.setDeDomicilio(rs.getString("NO_DOMICILIO"));
                ciudadano.setCoDepDomicilio(rs.getString("CO_DEPARTAMENTO_DOMICILIO"));
                ciudadano.setCoProDomicilio(rs.getString("CO_PROVINCIA_DOMICILIO"));
                ciudadano.setCoDisDomicilio(rs.getString("CO_DISTRITO_DOMICILIO"));
                ciudadano.setDeDepDomicilio(rs.getString("NO_DEPARTAMENTO_DOMICILIO"));
                ciudadano.setDeProDomicilio(rs.getString("NO_PROVINCIA_DOMICILIO"));
                ciudadano.setDeDisDomicilio(rs.getString("NO_DISTRITO_DOMICILIO"));
                return ciudadano;
                }
            );
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
