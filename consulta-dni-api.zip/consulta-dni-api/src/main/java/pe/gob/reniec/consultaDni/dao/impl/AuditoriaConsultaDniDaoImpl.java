package pe.gob.reniec.consultaDni.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import pe.gob.reniec.consultaDni.dao.AuditoriaConsultaDniDao;

@Repository
public class AuditoriaConsultaDniDaoImpl implements AuditoriaConsultaDniDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public String registrarConsultaDni(String dniConsultado, String usuarioId) {
        String sql = "INSERT INTO IDOADHEREN.cdtx_consulta_ciudadano_log(DNI_CONSULTA, USUARIO, FE_CREA_AUDI) values (?, ?, CURRENT_TIMESTAMP)";
        this.jdbcTemplate.update(sql, dniConsultado, usuarioId);
        return "1";
    }
}
