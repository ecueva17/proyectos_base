package pe.gob.reniec.consultaDni.service;

import pe.gob.reniec.consultaDni.model.Ciudadano;

public interface ConsultaDniService {
    public Ciudadano getCiudadano(String dni);
}
