package pe.gob.reniec.consultaDni.model.dto;

public class ResponseDTO<T> {
    private String mensaje;
    private T data;

    public ResponseDTO(String mensaje, T data) {
        this.mensaje = mensaje;
        this.data = data;
    }

    // Getters y Setters
    public String getMensaje() { return mensaje; }
    public T getData() { return data; }
}
