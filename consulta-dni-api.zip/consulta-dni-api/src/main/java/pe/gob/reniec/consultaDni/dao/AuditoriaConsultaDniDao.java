package pe.gob.reniec.consultaDni.dao;

public interface AuditoriaConsultaDniDao {
    public String registrarConsultaDni(String dniConsultado, String usuarioId);
}
