package pe.gob.reniec.consultaDni.dao;

import pe.gob.reniec.consultaDni.model.Ciudadano;

public interface ConsultaDniDao {
    public Ciudadano getCiudadano(String dni);
}
