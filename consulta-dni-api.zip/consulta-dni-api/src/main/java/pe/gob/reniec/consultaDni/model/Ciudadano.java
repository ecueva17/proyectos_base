package pe.gob.reniec.consultaDni.model;

public class Ciudadano {
    private String dni;
    private String nombre;
    private String apPaterno;
    private String apMaterno;
    private String apCasada;
    private String deDomicilio;
    private String coDepDomicilio;
    private String coProDomicilio;
    private String coDisDomicilio;
    private String deDepDomicilio;
    private String deProDomicilio;
    private String deDisDomicilio;

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPaterno() {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno) {
        this.apPaterno = apPaterno;
    }

    public String getApMaterno() {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) {
        this.apMaterno = apMaterno;
    }

    public String getApCasada() {
        return apCasada;
    }

    public void setApCasada(String apCasada) {
        this.apCasada = apCasada;
    }

    public String getDeDomicilio() {
        return deDomicilio;
    }

    public void setDeDomicilio(String deDomicilio) {
        this.deDomicilio = deDomicilio;
    }

    public String getCoDepDomicilio() {
        return coDepDomicilio;
    }

    public void setCoDepDomicilio(String coDepDomicilio) {
        this.coDepDomicilio = coDepDomicilio;
    }

    public String getCoProDomicilio() {
        return coProDomicilio;
    }

    public void setCoProDomicilio(String coProDomicilio) {
        this.coProDomicilio = coProDomicilio;
    }

    public String getCoDisDomicilio() {
        return coDisDomicilio;
    }

    public void setCoDisDomicilio(String coDisDomicilio) {
        this.coDisDomicilio = coDisDomicilio;
    }

    public String getDeDepDomicilio() {
        return deDepDomicilio;
    }

    public void setDeDepDomicilio(String deDepDomicilio) {
        this.deDepDomicilio = deDepDomicilio;
    }

    public String getDeProDomicilio() {
        return deProDomicilio;
    }

    public void setDeProDomicilio(String deProDomicilio) {
        this.deProDomicilio = deProDomicilio;
    }

    public String getDeDisDomicilio() {
        return deDisDomicilio;
    }

    public void setDeDisDomicilio(String deDisDomicilio) {
        this.deDisDomicilio = deDisDomicilio;
    }
}
