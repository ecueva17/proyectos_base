package pe.gob.reniec.consultaDni.model.dto;

import org.hibernate.validator.constraints.NotBlank;

public class CiudadanoRequestDTO {

    @NotBlank(message = "El DNI a consultar es obligatorio")
    private String dniConsulta;

    @NotBlank(message = "El usuario que consulta es obligatorio")
    private String usuarioConsulta;

    public String getDniConsulta() {
        return dniConsulta;
    }

    public void setDniConsulta(String dniConsulta) {
        this.dniConsulta = dniConsulta;
    }

    public String getUsuarioConsulta() {
        return usuarioConsulta;
    }

    public void setUsuarioConsulta(String usuarioConsulta) {
        this.usuarioConsulta = usuarioConsulta;
    }
}
