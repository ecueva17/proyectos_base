package pe.gob.reniec.consultaDni.service;

public interface AuditoriaConsultaDniService {
    public String registrarConsulta(String dniConsultado, String usuarioId);
}
