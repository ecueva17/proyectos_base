package pe.gob.reniec.consultaDni.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.gob.reniec.consultaDni.model.Ciudadano;
import pe.gob.reniec.consultaDni.model.dto.CiudadanoRequestDTO;
import pe.gob.reniec.consultaDni.model.dto.ResponseDTO;
import pe.gob.reniec.consultaDni.service.AuditoriaConsultaDniService;
import pe.gob.reniec.consultaDni.service.ConsultaDniService;

import javax.validation.Valid;

@RestController
public class ConsultaDniRestController {

    @Autowired
    private ConsultaDniService consultaDniService;

    @Autowired
    private AuditoriaConsultaDniService auditoriaConsultaDniService;

    @RequestMapping(value = "/healthcheck", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getHealthCheck(){
        return "{\"todoOk\": true}";
    }

    @RequestMapping(value = "/getCiudadano", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDTO<Ciudadano>> getCiudadano(@Valid @RequestBody CiudadanoRequestDTO ciudadanoRequest){
        Ciudadano ciudadano = this.consultaDniService.getCiudadano(ciudadanoRequest.getDniConsulta());
        if (ciudadano == null) {
            // Retornar 404 Not Found si no existe
            ResponseDTO<Ciudadano> response = new ResponseDTO<>("Ciudadano no encontrado", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
        auditoriaConsultaDniService.registrarConsulta(ciudadanoRequest.getDniConsulta(), ciudadanoRequest.getUsuarioConsulta());
        // 2. Si todo está bien, retornar 200 OK con el objeto y mensaje
        ResponseDTO<Ciudadano> response = new ResponseDTO<>("Consulta exitosa", ciudadano);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
