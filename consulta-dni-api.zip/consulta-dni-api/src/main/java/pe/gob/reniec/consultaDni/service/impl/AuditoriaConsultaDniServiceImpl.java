package pe.gob.reniec.consultaDni.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import pe.gob.reniec.consultaDni.dao.AuditoriaConsultaDniDao;
import pe.gob.reniec.consultaDni.service.AuditoriaConsultaDniService;

@Service
public class AuditoriaConsultaDniServiceImpl implements AuditoriaConsultaDniService {

    @Autowired
    private AuditoriaConsultaDniDao auditoriaConsultaDniDao;

    @Override
    public String registrarConsulta(String dniConsultado, String usuarioId) {
        return this.auditoriaConsultaDniDao.registrarConsultaDni(dniConsultado, usuarioId);
    }
}
