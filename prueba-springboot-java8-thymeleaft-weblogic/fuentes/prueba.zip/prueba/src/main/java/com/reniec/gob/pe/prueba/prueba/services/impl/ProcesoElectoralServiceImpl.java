package com.reniec.gob.pe.prueba.prueba.services.impl;

import com.reniec.gob.pe.prueba.prueba.dao.ProcesoElectoralDao;
import com.reniec.gob.pe.prueba.prueba.models.ProcesoElectoral;
import com.reniec.gob.pe.prueba.prueba.services.ProcesoElectoralService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class ProcesoElectoralServiceImpl implements ProcesoElectoralService {

    private final ProcesoElectoralDao procesoElectoralDao;

    public ProcesoElectoralServiceImpl(ProcesoElectoralDao procesoElectoralDao) {
        this.procesoElectoralDao = procesoElectoralDao;
    }


    @Override
    public List<ProcesoElectoral> getProcesoElectoral(String codigoProceso) {
        return procesoElectoralDao.getProcesoElectoral(codigoProceso);
    }

}
