package com.reniec.gob.pe.prueba.prueba.controllers;

import com.reniec.gob.pe.prueba.prueba.services.ProcesoElectoralService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ProcesoElectoralController {

    @Autowired
    private ProcesoElectoralService procesoElectoralService;

    @GetMapping("/proceso")
    public String procesoElectoral(Model model) {
        model.addAttribute("lProceso", procesoElectoralService.getProcesoElectoral("P1502"));
        return "consulta/consulta"; // Esto buscara el archivo index.html en templates
    }
}
