package com.reniec.gob.pe.prueba.prueba.services;

import com.reniec.gob.pe.prueba.prueba.models.ProcesoElectoral;

import java.util.List;

public interface ProcesoElectoralService {
    List<ProcesoElectoral> getProcesoElectoral(String codigoProceso);
}
