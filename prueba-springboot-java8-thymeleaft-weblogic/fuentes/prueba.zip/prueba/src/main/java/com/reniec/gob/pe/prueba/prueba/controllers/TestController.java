package com.reniec.gob.pe.prueba.prueba.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TestController {

    @GetMapping("/verificar")
    public String probarWeblogic(Model model) {
        model.addAttribute("mensaje", "¡Arquetipo Spring Boot 2.7 y Thymeleaf cargado con éxito en WebLogic!");
        return "index2"; // Esto buscará el archivo index.html en templates
    }
}
