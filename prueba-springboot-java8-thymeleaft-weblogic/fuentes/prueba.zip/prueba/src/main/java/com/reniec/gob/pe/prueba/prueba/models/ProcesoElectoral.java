package com.reniec.gob.pe.prueba.prueba.models;

public class ProcesoElectoral {
    private String codigo;
    private String nombre;

    public ProcesoElectoral() {
    }

    // Constructor
    public ProcesoElectoral(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    // Getters and Setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
