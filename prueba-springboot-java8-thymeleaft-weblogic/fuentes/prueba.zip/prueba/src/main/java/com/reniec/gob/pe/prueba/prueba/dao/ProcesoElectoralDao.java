package com.reniec.gob.pe.prueba.prueba.dao;

import com.reniec.gob.pe.prueba.prueba.models.ProcesoElectoral;

import java.util.List;

public interface ProcesoElectoralDao {
    List<ProcesoElectoral> getProcesoElectoral(String codigoProceso);
}
