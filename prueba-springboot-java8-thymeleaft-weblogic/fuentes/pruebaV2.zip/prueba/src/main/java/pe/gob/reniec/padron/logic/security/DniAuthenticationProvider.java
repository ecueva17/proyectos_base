package pe.gob.reniec.padron.logic.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

@Component
public class DniAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private UserDetailsService dniUserDetailsService;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        // Extraemos el DNI ingresado en el formulario (viaja en el campo 'username')
        String dni = authentication.getName();

        // 1. Validar que el DNI no venga vacío y cumpla con el formato peruano (8 dígitos)
        // Esto mitiga ataques de inyección de código desde la entrada del formulario
        if (dni == null || !dni.matches("^\\d{8}$")) {
            throw new BadCredentialsException("El número de DNI ingresado no es válido.");
        }

        // 2. Buscamos y validamos al ciudadano en el padrón (Base de Datos Oracle)
        // Si no existe, el método loadUserByUsername lanzará un UsernameNotFoundException
        UserDetails ciudadano = dniUserDetailsService.loadUserByUsername(dni);

        // 3. Devolvemos el token de autenticación completamente aprobado
        // Pasamos 'null' en las credenciales porque no requerimos contraseña
        // Pasamos las autoridades (ROLE_CIUDADANO) cargadas desde el servicio
        return new UsernamePasswordAuthenticationToken(
                ciudadano,
                null,
                ciudadano.getAuthorities()
        );
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
