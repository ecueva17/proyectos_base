package pe.gob.reniec.padron.logic.security;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class DniUserDetailsService implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String dni) throws UsernameNotFoundException {
        // Aquí colocarás tu lógica JDBC de Oracle.
        // Ejemplo temporal para pruebas locales:
        boolean existeEnPadron = true;

        if (!existeEnPadron) {
            throw new UsernameNotFoundException("Ciudadano no encontrado en el padrón.");
        }

        // Retornamos el usuario con el prefijo "ROLE_" requerido internamente por Spring
        return new User(
                dni,
                "", // Contraseña vacía segura
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_CIUDADANO"))
        );
    }
}
