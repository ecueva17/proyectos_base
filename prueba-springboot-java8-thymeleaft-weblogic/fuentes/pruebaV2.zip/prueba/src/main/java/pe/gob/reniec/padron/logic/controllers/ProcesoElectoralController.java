package pe.gob.reniec.padron.logic.controllers;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import pe.gob.reniec.padron.logic.services.ProcesoElectoralService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class ProcesoElectoralController {

    @Autowired
    private ProcesoElectoralService procesoElectoralService;

    @GetMapping("/proceso")
    public String procesoElectoral(Model model) {
        model.addAttribute("lProceso", procesoElectoralService.getProcesoElectoral("P1502"));
        return "consulta/consulta"; // Esto buscara el archivo index.html en templates
    }

    @GetMapping("/homereniec")
    public String reniecHome(HttpServletRequest request, HttpServletResponse response,
                             Model model, Authentication auth){
        // 2. Destruimos la sesión y desautenticamos de inmediato al usuario
        SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
        logoutHandler.logout(request, response, auth);
        return "consulta/home";
    }

}
