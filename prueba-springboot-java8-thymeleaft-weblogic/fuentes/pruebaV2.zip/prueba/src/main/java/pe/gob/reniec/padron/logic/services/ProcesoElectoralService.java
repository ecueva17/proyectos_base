package pe.gob.reniec.padron.logic.services;

import pe.gob.reniec.padron.logic.models.ProcesoElectoral;

import java.util.List;

public interface ProcesoElectoralService {
    List<ProcesoElectoral> getProcesoElectoral(String codigoProceso);
}
