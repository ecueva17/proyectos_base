package pe.gob.reniec.padron.logic.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private DniAuthenticationProvider dniAuthenticationProvider;

    @Bean
    public AuthenticationManager authManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
                http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.authenticationProvider(dniAuthenticationProvider);
        return authenticationManagerBuilder.build();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // Requisito de Internet: Forzar HTTPS
                //.requiresChannel().anyRequest().requiresSecure()
                //.and()

                // Cabeceras exigidas por auditores de seguridad (Anti-XSS, Clickjacking)
                .headers()
                .frameOptions().deny()
                .xssProtection().block(true).and()
                .contentTypeOptions().and()
                .contentSecurityPolicy("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';").and()
                .and()

                // Control de acceso a las rutas de tu WAR en WebLogic
                .authorizeRequests()
                // Permitir acceso libre a tus carpetas de Bootstrap local y al login
                .antMatchers("/css/**", "/js/**", "/login").permitAll()
                // Proteger estrictamente tu módulo de padrón en templates/consulta/
                //.antMatchers("/consulta/**").hasRole("ROLE_CIUDADANO")
                .antMatchers("/consulta/**").hasRole("CIUDADANO")
                .anyRequest().authenticated()
                .and()

                // Enlazar tu formulario de DNI hecho en Bootstrap 5
                .formLogin()
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .defaultSuccessUrl("/homereniec", true) // Tu archivo html de consulta
                .failureUrl("/login?error=true")
                .permitAll()
                .and()

                // Cierre de sesión limpio limpiando cookies de WebLogic
                .logout()
                .logoutUrl("/logout")
                //.logoutSuccessUrl("/login?logout=true")
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .deleteCookies("JSESSIONID")
                .permitAll();

        return http.build();
    }
}
