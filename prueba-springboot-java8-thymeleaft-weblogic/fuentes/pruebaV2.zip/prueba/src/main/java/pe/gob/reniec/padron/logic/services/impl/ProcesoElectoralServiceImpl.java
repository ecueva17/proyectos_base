package pe.gob.reniec.padron.logic.services.impl;

import pe.gob.reniec.padron.logic.dao.ProcesoElectoralDao;
import pe.gob.reniec.padron.logic.models.ProcesoElectoral;
import pe.gob.reniec.padron.logic.services.ProcesoElectoralService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProcesoElectoralServiceImpl implements ProcesoElectoralService {

    private final ProcesoElectoralDao procesoElectoralDao;

    public ProcesoElectoralServiceImpl(ProcesoElectoralDao procesoElectoralDao) {
        this.procesoElectoralDao = procesoElectoralDao;
    }


    @Override
    public List<ProcesoElectoral> getProcesoElectoral(String codigoProceso) {
        return procesoElectoralDao.getProcesoElectoral(codigoProceso);
    }

}
