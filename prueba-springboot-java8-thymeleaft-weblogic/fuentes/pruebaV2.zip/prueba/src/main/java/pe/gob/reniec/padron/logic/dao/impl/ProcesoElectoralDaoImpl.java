package pe.gob.reniec.padron.logic.dao.impl;

import pe.gob.reniec.padron.logic.dao.ProcesoElectoralDao;
import pe.gob.reniec.padron.logic.models.ProcesoElectoral;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;

@Repository
public class ProcesoElectoralDaoImpl implements ProcesoElectoralDao {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public ProcesoElectoralDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<ProcesoElectoral> getProcesoElectoral(String codigoProceso) {
        return jdbcTemplate.query(
                "SELECT co_proceso_electoral codigo, de_proceso_electoral nombre FROM idolpi.cgtm_proceso_electoral WHERE co_proceso_electoral = :codigoProceso",
                Collections.singletonMap("codigoProceso", codigoProceso),
                new BeanPropertyRowMapper<>(ProcesoElectoral.class)
        );
    }
}
