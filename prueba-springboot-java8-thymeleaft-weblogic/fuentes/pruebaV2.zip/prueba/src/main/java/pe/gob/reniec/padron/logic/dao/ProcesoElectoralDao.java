package pe.gob.reniec.padron.logic.dao;

import pe.gob.reniec.padron.logic.models.ProcesoElectoral;

import java.util.List;

public interface ProcesoElectoralDao {
    List<ProcesoElectoral> getProcesoElectoral(String codigoProceso);
}
