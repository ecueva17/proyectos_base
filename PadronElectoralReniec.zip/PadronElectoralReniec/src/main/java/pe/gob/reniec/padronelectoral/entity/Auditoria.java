/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.entity;

/**
 *
 * @author hcruz
 */
public class Auditoria {

    String es_registro;
    String us_crea_audi;
    String fe_crea_audi;
    String us_modi_audi;
    String fe_modi_audi;

    public Auditoria() {

    }

    public String getEs_registro() {
        return es_registro;
    }

    public void setEs_registro(String es_registro) {
        this.es_registro = es_registro;
    }

    public String getUs_crea_audi() {
        return us_crea_audi;
    }

    public void setUs_crea_audi(String us_crea_audi) {
        this.us_crea_audi = us_crea_audi;
    }

    public String getFe_crea_audi() {
        return fe_crea_audi;
    }

    public void setFe_crea_audi(String fe_crea_audi) {
        this.fe_crea_audi = fe_crea_audi;
    }

    public String getUs_modi_audi() {
        return us_modi_audi;
    }

    public void setUs_modi_audi(String us_modi_audi) {
        this.us_modi_audi = us_modi_audi;
    }

    public String getFe_modi_audi() {
        return fe_modi_audi;
    }

    public void setFe_modi_audi(String fe_modi_audi) {
        this.fe_modi_audi = fe_modi_audi;
    }
    
    
}
