/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.reniec.padronelectoral.util;

/**
 *
 * @author hcruz
 */
public final class NombreDeTablasUtil {

    public final static String Archivo_generado = "IDOLPI.CGTM_ARCHIVO_GENERADO_MCP";
    public final static String Archivo_generado_historico = "IDOLPI.CGTH_ARCH_GEN_HIS_MCP";
    public final static String Ciudadano = "IDOLPI.CGTM_ANI_LPI_MCP";
    public final static String Modulo = "idolpi.cgtm_modulos";
    public final static String ModuloPorRol = "idolpi.cgtv_modulos_x_rol";
    public final static String Rol = "idolpi.cgtm_roles";
    public final static String UsuarioPorRol = "idolpi.cgtm_usuario_rol";
    public final static String Usuario = "idolpi.cgtm_usuario";
    public final static String Proceso_electoral = "idolpi.cgtm_proceso_electoral";
    public final static String UbigeoPorProceso = "IDOLPI.CGTV_UBIGEO_MCP_X_PROC";
    public final static String Restriccion = "GETM_RESTRICCION";
    public final static String ParametroDetalle = "idolpi.cgtd_parametro";
    public final static String Ubigeo = "IDOLPI.CGTM_UBIGEOS_MCP";

}
